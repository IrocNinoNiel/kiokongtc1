<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Hazel Alegbeleye
 * Module: Affiliate Settings
 * Date: Oct 28, 2019
 * Finished: 
 * Description: The Affiliate Settings module allows only authorized users to setup (add, edit, or delete) affiliate details.
 * DB Tables: affiliate, employee, location
 * */ 
class Affiliatesettings extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'admin/Affiliatesettings_model' );
    }


    // public function getLocations() {
    //     $params = getData();
    //     $view = $this->model->getLocations( $params );
    //     die(
	// 		json_encode(
	// 			array(
	// 				'success' => true
    //                 ,'view' => $view['view']
	// 				,'total' => $view['count']
	// 			)
	// 		)
	// 	);
    // }

    public function getAffiliates() {
        $params = getData();
        $view = $this->model->getAffiliates( $params );
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view['view']
					,'total' => $view['count']
				)
			)
		);
    }

    public function getApprovers() {
        $params = getData();
        $view = $this->model->getApprovers( $params );
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
		);
    }

    public function saveAffiliate() {
        $params     = getData();
        $view       = $this->model->saveAffiliate( $params );
        $mainTag    = $this->model->checkMainTag();

        $affiliate = $this->model->getAffiliate( $view );
        $msg = ( !$params['onEdit'] ) ? 'Modified the affiliate, ' : 'Added new affiliate, ' ; 


        setLogs(
            array(
                'actionLogDescription' => $msg . $affiliate['view'][0]['affiliateName']
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 4
                ,'time'                => date("H:i:s A")
            )
        );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'match' => $view['match']
                    ,'idAffiliate' => isset( $view['idAffiliate'] ) ? $view['idAffiliate'] : ''
                    ,'mainTag'  => $mainTag
                )
            )
        );
    }

    public function deleteAffiliate(){
        $data = getData( false );
        $match = $this->model->deleteAffiliate( $data );
        $affiliate = $this->model->getAffiliate( $data );

        setLogs(
            array(
                'actionLogDescription' => 'Deleted the affiliate, ' . $affiliate['view'][0]['affiliateName']
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 4
                ,'time'                => date("H:i:s A")
            )
        );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $match
                )
            )
        );
    }

    public function setMainTag(){
        $data = getData( false );

        $this->model->setMainTag( $data );

        die(
            json_encode(
                array(
                    'success' => true
                )
            )
        );
    }
    
    public function getAffiliate() {
        $params     = getData();
        $data       = $this->model->getAffiliate( $params );
        $mainTag    = $this->model->checkMainTag();

        die(
			json_encode(
				array(
                    'success' => true
                    ,'view' => (array)$data['view']
                    ,'rec_match' => ( (int)$data['count'][0]['count'] > 0 ? 1 : 0 ) // Match: 1 = USED && 0 = USED
                    ,'mainTag' => $mainTag
				)
			)
		);
    }

    public function printPDF(){
        $params = getData();
        $list = $this->model->getAffiliates( $params );

        $header = array(
			array(
				'header'    =>  'Affiliate Name'
				,'dataIndex'=>  'affiliateName'
				,'width'    =>  '16%'	
            ),
            array(
				'header'    =>  'Address'
				,'dataIndex'=>  'address'
				,'width'    =>  '20%'	
            ),
            array(
				'header'    =>  'Contact Person'
				,'dataIndex'=>  'contactPerson'
				,'width'    =>  '16%'	
            ),
            array(
				'header'    =>  'Email'
				,'dataIndex'=>  'email'
				,'width'    =>  '16%'	
            ),
            array(
				'header'    =>  'TIN'
				,'dataIndex'=>  'tin'
				,'width'    =>  '16%'	
            ),
            array(
				'header'    =>  'Status'
				,'dataIndex'=>  'status'
				,'width'    =>  '16%'	
            )
        );
        
        $array = array(
			'file_name'	        => $params['pageTitle']
			,'folder_name'      => 'admin'
			,'records'          => $list['view']
            ,'header'           => $header
            ,'hasSignatories'   => 0
       );
       
       generateTcpdf($array);
    }
}