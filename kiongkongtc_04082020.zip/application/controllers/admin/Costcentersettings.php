<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Hazel Alegbeleye
 * Module: Cost Center Settings
 * Date: Oct 29, 2019
 * Finished: 
 * Description: 
 * DB Tables: 
 * */ 
class Costcentersettings extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'admin/Costcentersettings_model' );
    }

    public function getAffiliates() {
        $params = getData();
        $view = $this->model->getAffiliates( $params );

        // LQ();

        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view['view']
					,'total' => $view['count']
				)
			)
		);
    }

    public function getCostCenters() {
        $params = getData();
        $view = $this->model->getCostCenters( $params );
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view['view']
					,'total' => $view['count']
				)
			)
		);
    }

    public function getCostCenter() {
        $params = getData();
        $view = $this->model->getCostCenter( $params );
        die(
			json_encode(
				array(
                    'success' => true
                    ,'view' => $view
				)
			)
		);
    }

    public function deleteCostCenter(){
        $data = getData();
        $match = $this->model->deleteCostCenter( $data );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $match
                )
            )
        );
    }

    public function saveCostCenter() {
        $params = getData( true );
        $idCostCenter = $this->model->saveCostCenter( $params );
        $match = ( empty($idCostCenter) || $idCostCenter < 0 ) ? 1 : 0;

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => array( 'idCostCenter' => $idCostCenter, 'match' => $match )
                )
            )
        );
    }

    
    public function saveCostAffiliate() {
        $params = getData();
        $view = $this->model->saveCostAffiliate( $params );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    public function updateCostCenter(){
        $data = getData( false );
        $view = [];
        $view = $this->model->updateCostCenter( $data );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    public function generateCostCenterPDF(){
        $data = getData();
        $list = $this->model->getCostCenters($data); 

        $header = array(
			array(
				'header'=>'Cost Center Name'
				,'dataIndex'=>'costCenterName'
				,'width'=>'50%'	
			),
			array(
				'header'=>'Status'
				,'dataIndex'=>'status'
                ,'width'=>'50%'
			),
		);

		$array = array(
			'file_name'	=> $data['pageTitle']
			,'folder_name' => 'admin'
			,'records' =>  $list['view']
			,'header' => $header
       );
       
    //    $data['ident'] = null;
       generateTcpdf($array);
    }

    public function printCostCenterExcel ()
	{
		
		$data = getData();
		$sum = 0;
		$view = $this->model->getCostCenters( $data );
		$csvarray[] = array( 'title' => $data['pageTitle'].'' );
		$csvarray[] = array( 'space' => '' );
		$csvarray[] = array( 'space' => '' );

		$csvarray[] = array(
			'col1' => 'Cost Center Name'
			,'col2' => 'Status'
		);
		
		foreach( $view['view'] as $value ){
			$csvarray[] = array(
				'col1' => $value[ 'costCenterName' ]
				,'col2' => $value[ 'status' ]
			);
        }
        
		$data['description'] = '' .$data['pageTitle']. ": " .$this->USERNAME. ' printed a Excel report'  ;
		$data['iduser'] = $this->USERID;
		$data['usertype'] = $this->USERTYPEID;
		$data['printExcel'] = true;	
        $data['ident'] = null;

		writeCsvFile(
			array(
				'csvarray' 	 => $csvarray
				,'title' 	 => $data['pageTitle'].''
				,'directory' => 'admin'
			)
		);
		
    }
    
    function download($title){
		force_download(
			array(
				'title' => $title
				,'directory' => 'admin'
			)
		);
    }
    
    public function getSearchCostCenter(){
        $params = getData();
        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $this->model->getSearchCostCenter( $params )
                )
            )
        );
    }
}