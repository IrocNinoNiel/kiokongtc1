<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Jayson Dagulo
 * Module: Standards2(Additional file for standards to be applied only on this Project)
 * Date: Oct 21, 2019
 * Finished: 
 * Description: This contains the functions and components that are considered a standard only for this project
 * */ 
class Standards2 extends CI_Controller {
    
    /* Class constructor */
    public function __construct(){
        parent::__construct();
        setHeader( 'standards/Standards2_model' );
    }

    public function getAffiliate(){
        $params = getData();
        $view   = $this->model->getAffiliate( $params, $this->session->userdata('EMPLOYEEID') );

        // LQ();

        if( isset($params['hasAll']) ) {
            array_unshift( $view, array(
                'id' => 0
                ,'name' => 'All'
            ));
        }

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    public function getReference(){
        $params = getData();
        $view   = $this->model->getReference( $params );

        // LQ();

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    public function getLocationCmb(){
        $params = getData();
        $view   = $this->model->getLocationCmb( $params );

        if( (int)$params['hasAll'] == 1 ){
            array_unshift(
                $view
                ,array(
                    'id'    => 0
                    ,'name' => 'All'
                )
            );
        }

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    public function getSupplierCmb(){
        $params = getData();
        $view   = $this->model->getSupplierCmb( $params );

        if( (int)$params['hasAll'] == 1 ){
            array_unshift(
                $view
                ,array(
                    'id'    => 0
                    ,'name' => 'All'
                )
            );
        }

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    public function getCostCenter(){
        $params = getData();
        $view   = $this->model->getCostCenter( $params );

        if( isset($params['hasAll']) ) {
            array_unshift( $view, array(
                'id' => 0
                ,'name' => 'All'
            ));
        }
        
        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    public function getReferenceNum(){
        $params = getData();
        $params['tableName'] = 'invoices';
        $view   = $this->model->getReferenceNum( $params );

        // LQ();

        /*  MATCH
            0 - SUCCESS
            1 - NOT_FOUND
            2 - MAX SERIES EXCEEDED
        */


        // die( json_encode( $view ) );
        
        // print_r( $view );
        
        // if( !empty( $view ) ) {
        //     $currentSeries = [];

        //     foreach( $view as $val ){
        //         $result = $this->model->_getRefNum( $val ); //Used to get the current available reference number

        //         $currentRefNum = (int)$result['referenceNum'];
        //         $seriesFrom = (int)$val['seriesFrom'];
        //         $seriesTo = (int)$val['seriesTo'];
                
        //         die( json_encode(array(
        //             'from' => $seriesFrom
        //             ,'to'  => $seriesTo
        //             ,'refNum' => $currentRefNum
        //         )));

        //         if( $currentRefNum > $seriesFrom && $currentRefNum < $seriesTo ){
        //             $currentSeries['refnum'] = $currentRefNum + 1;
        //             $currentSeries['idRef'] = (int)$val['idReferenceSeries'];
        //         }

        //         // switch( true ){
        //         //     case $currentRefNum > $seriesFrom && $currentRefNum < $seriesTo:
        //         //         $currentSeries['refnum'] = $currentRefNum + 1;
        //         //         $currentSeries['idRef'] = (int)$val['idReferenceSeries'];
        //         //         break;
        //         //     case $currentRefNum == $seriesFrom:
        //         //         $currentSeries['refnum'] = $currentRefNum;
        //         //         $currentSeries['idRef'] = (int)$val['idReferenceSeries'];
        //         //         break;
        //         //     // default:
        //         //     //     $response = 2;
        //         //     //     break;
        //         // }

        //         die( json_encode( $currentSeries ));

                
        //     }

        //     // echo 'Result: </br>';
        //     // print_r( $currentSeries );
            
        //     // var_dump( $currentSeries );

        //     $response = ( !$currentSeries ) ? array('refnum' => (int)$view[0]['seriesFrom'] , 'idRef' => $view[0]['idReferenceSeries']) : 2;

        //     // switch( true ){
        //     //     case empty( $currentSeries ):
                    
        //     //         break;
        //     //     case !empty( $response ):
        //     //         $response = 2;
        //     //         break;
        //     // }

        // } else {
        //     $response = 1;
        // }

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => empty( $view ) ? array( 'match' => 1) : $view[0]
                )
            )
        );
    }

    public function getItem( $pType = '' ){
        $params = getData();
        
        if( isset( $pType ) && $pType != '' ) {
            if( $pType == 1 ) {
                $view   = $this->model->getSupplierItems( $params );
            } elseif( $pType == 2 ) {
                $view   = $this->model->getCustomerItems( $params );
            }
        }

        // LQ();

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    public function getSupplier(){
		$params = getData();
        $view	= $this->model->getSupplier( $params );

        if( isset($params['hasAll']) ) {
            array_unshift( $view, array(
                'id' => 0
                ,'name' => 'All'
            ));
        }
        
		die(
			json_encode(
				array(
					'success'	=> true
					,'view'		=> $view
				)
			)
		);
    }
    
    function updateTransactionStatus() {
        $params = getData();
        $params['notedby'] = $this->session->userdata('USERID');
        $result = $this->model->updateTransactionStatus( $params );

        $transType = (int)$params['status'];

        if( isset($params['username']) ) {
            setLogs( array(
                'actionLogDescription' =>  ($transType == 2 ) ? $params['username'].' approved a Cash Receipt Transaction' : $params['username'].' cancelled a Cash Receipt Transaction' 
                ,'idEu' => $params['notedBy']
                ,'moduleID' => 28
                ,'time' => date("H:i:s A")
            ));
        }
		
        die( 
			json_encode(
                array(
                    'success' => true
                    ,'match' => ( $result <= 0 ) ? 0 : 1 
                )
            )
        );
    }

    function getItems(){
        $params = getData();
        $view = $this->model->getItems( $params );

        // LQ();

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view'   => $view
                )
            )
        );
    }

    public function getItemsCombo(){
        $params     = getData();
        $hasAll     = ( isset( $params['hasAll'] )? (int)$params['hasAll'] : 0 );
        $view       = $this->model->getItemsCombo( $params );

        if( $hasAll > 0 && !isset( $params['query'] ) ){
            array_unshift(
                $view['view']
                ,array(
                    'idItem'    => 0
                    ,'barcode'  => 'All'
                    ,'itemName' => 'All'
                )
                );
        }

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view['view']
                    ,'total'    => $view['count']
                )
            )
        );
    }

    public function getCOACombo(){
        $params     = getData();
        $hasAll     = ( isset( $params['hasAll'] )? (int)$params['hasAll'] : 0 );
        $view       = $this->model->getCOACombo( $params );
        
        if( $hasAll > 0 && !isset( $params['query'] ) ){
            array_unshift(
                $view['view']
                ,array(
                    'idCoa'         => 0
                    ,'acod_c15'     => 'All'
                    ,'aname_c30'    => 'All'
                )
            );
        }

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view['view']
                    ,'total'    => $view['count']
                )
            )
        );
    }
    
}