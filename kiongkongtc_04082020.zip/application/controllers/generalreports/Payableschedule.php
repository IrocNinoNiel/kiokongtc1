<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Mark Reynor D. Magriña
 * Module: Payable Schedule
 * Date: Feb 18, 2020
 * Finished: 
 * Description: 
 * DB Tables: 
 * For Password Hashing, please use password_hash( https://www.php.net/manual/en/function.password-hash.php )
 * */
class Payableschedule extends CI_Controller {
	public function __construct(){
		parent::__construct();
		setHeader('generalreports/Payableschedule_model');
	}
	
	public function getHistory(){
		$rawData = getData();
        $record = $this->model->recordDetails( $rawData );
		die( json_encode( array( 'success' => true ,'view' => $record ,'total' => Count($record) ) ) );	
		// die( json_encode( array( 'success' => true ,'view' => $list['view'] ,'total' => $list['count'] ) ) );	
	}
	// function getSupplier(){
		// $rawData = getData();
		// $record = $this->model->getSupplier($rawData);
		// die( json_encode( array('success'=> true, 'view'=>$record ) ) );
	// }
	
	
	
	public function printPDF(){
		$data = getData();
		$data['pdf'] = true;
		$list = $this->model->viewAll( $data );
		
		$params1 = array(
			array(   
				'header' => 'Date'	
				,'dataIndex' => 'datelog'				
				,'width' => '8%'
			)
			,array(  
				'header' => 'Time'	
				,'dataIndex' => 'time'			
				,'width' => '8%'		
			)
			,array(  
				'header' => 'Location' 			
				,'dataIndex' => 'affiliateName'				
				,'width' => '10%'		
			)
			,array(   
				'header' => 'User Fullname' 			
				,'dataIndex' => 'fullname'			
				,'width' => '10%'
			)
			,array(   
				'header' => 'User Name'		
				,'dataIndex' => 'euName'		
				,'width' => '10%'
			)
			,array(  
				'header' => 'User Type'		
				,'dataIndex' => 'euTypeName'		
				,'width' => '10%'
			)
			,array(
				'header' => 'User Type'		
				,'dataIndex' => 'euTypeName'		
				,'width' => '10%'
			)
			,array(
				'header' => 'Ref'		
				,'dataIndex' => 'ref'		
				,'width' => '5%'
			)
			,array(
				'header' => 'Number'		
				,'dataIndex' => 'refnum'		
				,'width' => '8%'
			)
			,array(
				'header' => 'Description'		
				,'dataIndex' => 'actionLogDescription'		
				,'width' => '23%'
			)
		);
		
		$header_fields = array(
			array(
				array(
					'label' => 'Affiliate'
					,'value' => $data['rawaffiliateID']
				)
				,array(
					'label' => 'Select User'
					,'value' => $data['rawsearchBy']
				)
				,array(
					'label' => 'Date'
					,'value' => $data['rawsdate']
				)
				,array(
					'label' => 'To'
					,'value' => $data['rawedate']
				)
			)
		);
		
		$html = 'Total';
		
		generateTcpdf(
			array(
				'file_name' => $data['title']
				,'folder_name' => 'admin'
				,'records' => $list
				,'header' => $params1
				,'orientation' => 'L'
				,'header_fields' => $header_fields
			)
		);
	}
	
	public function viewPDF( $title ){
		viewPDF(
			array(
				'file_name' => $title
				,'folder_name' => 'admin'
			)
		);
	}
}
