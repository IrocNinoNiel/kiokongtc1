<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Mark Reynor D. Magri�a
 * Module: Disbursements Module
 * Date: Feb 10, 2020
 * Finished: 
 * Description: 
 * DB Tables: 
 * For Password Hashing, please use password_hash( https://www.php.net/manual/en/function.password-hash.php )
 * */
class Disbursements extends CI_Controller {

	public function __construct(){
        parent::__construct();
        setHeader( 'accounting/Disbursements_model' );
    }
	
	function getGridListForPayments(){
		$rawData = getData();
		$record = $this->model->getGridListForPayments( $rawData ) ;
		die( json_encode( array( 'success'=>true, 'view'=> $record ) ) );
	}
	
	
	function saveStockTransferForm(){		
		$rawData = getData();
		$rawData['pType'] = 2;
		print_r($rawData);
		die();		
		
		$this->db->trans_begin();// firstline		
		$stInvoiceID = $this->model->saveInvoiceStockTransfer($rawData);
		
		/* Set the invoice id according to transaction state. */
		if( (int)$rawData['onEdit'] == 0 ) { $stInvoiceID = $stInvoiceID;}
		else{ $stInvoiceID = (int)$rawData['idInvoice']; }
		
		/* Prepare stock transfer details for batch saving */
		$gridItemList = json_decode( $rawData['gridItemList'] , true );
		for( $i=0; $i < count($gridItemList); $i++ ){
			$gridItemList[$i]['idInvoice'] = $stInvoiceID;
		}
		$this->model->saveGridItemList($gridItemList,$stInvoiceID);
		
		/* Set the journal details for batch saving */
		$journalDetails = json_decode( $rawData['journalDetails'],true );
		for( $i=0; $i < count($journalDetails); $i++ ){
			$journalDetails[$i]['idInvoice'] = $stInvoiceID;
		}
		$this->model->saveJournalDetails($journalDetails,$stInvoiceID);		
		/* Set Logs */
		if($rawData['onEdit'] == 0){ $actioLog = $this->USERNAME.' transferred stocks to '. $rawData['receiverAffiliate']; }
		else{ $actioLog = $this->USERNAME.' edited a transaction'; }
		setLogs( array(
			'actionLogDescription' => $actioLog
			,'idEu' => $this->USERID
			,'moduleID' => 43
			,'time' => date("H:i:s A")
		));
		
		if( $this->db->trans_status() === FALSE ){
			$this->db->trans_rollback(); // rollback changes
		}
		else{
			$this->db->trans_commit(); // submit changes
		}
		die( json_encode( array( 'success'=>$this->db->trans_status(), 'match'=>0 ) ) );
	}
	
	function saveCashReceiptsForm(){
		$rawData = getData();
		
		// $rawData['pCode'] = $rawData['supplier']; /* already in the post data */
		$rawData['preparedBy'] = $this->session->userdata('USERID');
		$rawData['pType'] = 3;
		$rawData['pCode'] = $rawData['supplierCmb'];
		$rawData['hasJournal'] = 1;
		$rawData['amount'] = (float)$rawData['totalAmountDisbursed'] + (float)$rawData['discount'];
		$rawData['discount'] = (float)$rawData['discount'];
		$rawData['status'] = 2;
		
		
		// print_r($rawData);
		// die();
		
		
		
		$this->db->trans_begin();// firstline	
		
		$dsInvoiceID = $this->model->saveInvoiceDisbursements($rawData);
		
		/* Set the invoice ID according to transaction state */
		if ( (int)$rawData['onEdit'] == 0 ){ $dsInvoiceID = $dsInvoiceID; }
		else{ $dsInvoiceID = (int)$rawData['idInvoice']; }
		
		
		/* Return the amount to the balance left in invoices and then delete the related records */
		$getPayables = $this->model->getPayables($dsInvoiceID);
		foreach( $getPayables as $rs){
			$getBalLeft = $this->model->getBalLeft( $rs['fident']);
			$balLeft = ($getBalLeft) ? (float)$getBalLeft->balleft : 0;
			$this->model->updateBalLeft( $rs['fident'], (float)$rs['amount'] + $balLeft );
		}
		
		/* Delete disbursement details in receipt and postdated tables */
		$this->model->delReceiptsDetails($dsInvoiceID);
		$this->model->delPostdatedDetails($dsInvoiceID);
		
		/* Prepare disbursement details for batch processing */
		$paidDetails = json_decode( $rawData['paidDetails'], true );
		if( !empty( $paidDetails ) ){
			for( $i=0; $i < count($paidDetails); $i++ ){
				$paidDetails[$i]['idInvoice'] = $dsInvoiceID;
				$paidDetails[$i]['idCustomer'] = $rawData['pCode'];
				$paidDetails[$i]['amount'] = $paidDetails[$i]['paid'];
				$paidDetails[$i]['fident'] = $paidDetails[$i]['sourceIDInvoice'];
				
				/* Get current updated balance left */
				$getBalLeft = $this->model->getBalLeft( $paidDetails[$i]['sourceIDInvoice'] );
				$balLeft = ($getBalLeft) ? (float)$getBalLeft->balLeft : 0;
				/* To add validations incase the balance left is zero */
				// to later for the returned items where bal left is not enough to be deducted.
				
				/* Update the invoices balance left */
				$this->model->updateBalLeft( $paidDetails[$i]['sourceIDInvoice'], $balLeft - (float)$paidDetails[$i]['amount'] );
			}
			$this->model->saveDisbursementDetails( $paidDetails,$dsInvoiceID );
		}
		
		/* Prepare posdated details for batch saving */
		$paymentList = json_decode( $rawData['paymentList'], true);
		for( $i=0; $i < count($paymentList); $i++ ){
			$paymentList[$i]['idInvoice'] = $dsInvoiceID;
			$paymentList[$i]['paymentMethod'] = $paymentList[$i]['typeID'];
		}
		$this->model->savePaymentList( $paymentList,$dsInvoiceID );
		
		/* Prepare journal entries for batch saving */
		$journalDetails = json_decode( $rawData['journalDetails'], true );
		if( !empty($journalDetails) ){
			for( $i=0; $i < count($journalDetails); $i++ ){
				$journalDetails[$i]['idInvoice'] = $dsInvoiceID;
			}
			$this->model->saveJournalDetails($journalDetails,$crInvoiceID);
		}


		





		// Save	<username> added a new disbursement transaction
		// Edit	<username> edited a transaction
		// Delete	<username> deleted a transaction
		// Cancel	<username> cancelled a transaction
		// Confirm	<username> confirmed a disbursement transaction

		
		/* Set Logs */
		if($rawData['onEdit'] == 0){ $actioLog = $this->USERNAME.' added a new disbursement transaction.'; }
		else{ $actioLog = $this->USERNAME.' edited a transaction'; }
		setLogs( array(
			'actionLogDescription' => $actioLog
			,'idEu' => $this->USERID
			,'moduleID' => 45
			,'time' => date("H:i:s A")
		));
		if( $this->db->trans_status() === FALSE ){
			$this->db->trans_rollback(); // rollback changes
		}
		else{
			$this->db->trans_commit(); // submit changes
		}
		die( json_encode( array( 'success'=>$this->db->trans_status(), 'match'=>0 ) ) );
	}	
	function deleteStockTransferRecord(){
		$rawData = getData();
		$match = 0;
		/* Create a filtering process to check if the Items received were still intact if not, prohibit delete */
		
		/* Add code block here to delete the ST releasing, ST Receiving if not used by releasing module */
		$this->model->deleteStockTransferRecord($rawData['idInvoice']);
		$this->model->deleteStockTransferDetails($rawData['idInvoice']);
		
		setLogs( array(
			'actionLogDescription' => $this->USERNAME.' deleted a transaction'
			,'idEu' => $this->USERID
			,'moduleID' => 43
			,'time' => date("H:i:s A")
		));
		die( json_encode( array( 'success'=>true, 'match'=> $match ) ) );
	}
	function getDisbursementDetails(){
		$rawData = getData();
		
		$record = $this->model->getDisbursementDetails($rawData);
		die( json_encode( array( 'success'=>true, 'view'=>$record ) ) );
	}
	function getBankDetails(){
		$rawData = getData();
		$record = $this->model->getBankDetails($rawData);
		die( json_encode( array( 'success'=>true, 'view'=> $record ) ) );
	}
	function getSupplier(){
		$rawData = getData();
		$record = $this->model->getSupplier($rawData);
		die( json_encode( array('success'=> true, 'view'=>$record ) ) );
	}
	function getPayablesList(){
		$rawData = getData();
		$record = $this->model->getPayablesList($rawData);
		die( json_encode( array( 'success'=>true, 'view'=>$record ) ) );
	}
	function getCollectionDetails(){
		$rawData = getData();
		$record = $this->model->getCollectionDetails($rawData);
		die( json_encode( array( 'success'=>true, 'view'=>$record ) ) );
	}
	function retrieveData(){
		$rawData = getData();
		$match = 0;
		$idInvoice = $rawData['idInvoice'];
		$record = $this->model->retrieveData($idInvoice);
		die( json_encode( array( 'success'=>true, 'match'=> $match, 'view'=> $record ) ) );
	}
	function deleteDisbursementRecord(){
		$rawData = getData();
		$match = 0;
		
		$getPayables = $this->model->getPayables($rawData['idInvoice']);
		foreach( $getPayables as $rs){
			$getBalLeft = $this->model->getBalLeft($rs['fident']);
			$balLeft = ($getBalLeft) ? (float)$getBalLeft->balLeft : 0;
			$this->model->updateBalLeft( $rs['fident'],(float)$rs['amount'] + $balLeft );
		}		
		$this->model->deleteDisbursement($rawData['idInvoice']);
		$this->model->delReceiptsDetails($rawData['idInvoice']);
		$this->model->delPostdatedDetails($rawData['idInvoice']);
		
		setLogs( array(
			'actionLogDescription' => $this->USERNAME.' deleted a transaction'
			,'idEu' => $this->USERID
			,'moduleID' => 45
			,'time' => date("H:i:s A")
		));
		die( json_encode( array( 'success'=>true, 'match'=> $record ) ) );
	}

}