<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer    : Jayson Dagulo
 * Module       : Chart of account Settings
 * Date         : Dec 19, 2019
 * Finished     : Feb 03, 2020
 * Description  : This module allows authorized users to set (add, edit and delete) an account that will be used in journal entries.
 * DB Tables    : coa, coahistory, coaaffiliate, coaaffiliatehistory and logs
 * */ 
class Chartofaccounts extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'accounting/Chartofaccounts_model' );
    }

    public function headerAccountStore(){
		$all = $this->model->getHeader( getData() );  
        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $all
                )
            )
        );
    }
    
	public function getAccCode(){
		$result   = array();
		$data     = getData();
        $getAccod = $this->model->getAccod( $data );

		if( (int)$data['accountType'] == 1 ){
			$data['accod_c2'] = $getAccod['accod_c2'] + 1;
			$data['sucod_c3'] = 0;
        }
        else{
			$sucod  		  = $this->model->getSucod( $data ); 
			$data['sucod_c3'] = $sucod['sucod_c3'] + 1;
		}
		$result[]   = array(
			'mocod_c1'  => $data['mocod_c1']
			,'chcod_c1' => $data['chcod_c1']
			,'accod_c2' => str_pad ($data['accod_c2'] ,2, "0", STR_PAD_LEFT )
			,'sucod_c3' => str_pad( $data['sucod_c3'] ,3, "0", STR_PAD_LEFT )
			,'code_c7'  => $data['mocod_c1'] . $data['chcod_c1'] . str_pad($data['accod_c2'] , 2, "0", STR_PAD_LEFT ) . str_pad( $data['sucod_c3'] , 3, "0", STR_PAD_LEFT )
		);
        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $result
                )
            )
        ); 
    }
    
    public function getCoaAffiliate(){
        $params = getData();
        $view   = $this->model->getCoaAffiliate( $params );
        for( $i = 0; $i < count( (array)$view ); $i++ ){
            $coaIsUsed  = $this->model->checkCoaAffiliate( (int)$params['idCoa'], $view[$i]['idAffiliate'] );
            $view[$i]['def'] = ( $coaIsUsed > 0? 1 : 0 );
        }
        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    public function getHistory(){
        $params         = getData();
        $params['pdf']  = true;
        $view           = $this->model->getHistory( $params );
        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    public function saveForm(){
        $params = getData();
        $onEdit = $params['onEdit'];

        /** check code **/
        if( _checkData(
            array(
                'table'		=> 'coa'
                ,'field'   	=> 'acod_c15'
                ,'value'   	=> $params['acod_c15']
                ,'exwhere'	=> ( $onEdit ) ? 'idCoa != '.$params['idCoaOld'] : null
            )
        ) ){
            die(
                json_encode(
                    array(
                        'success' => true
                        ,'match' => 1
                    )
                )
            );
        }
        if(
            _checkData(
                array(
                    'table'		=> 'coa'
                    ,'field'   	=> 'aname_c30'
                    ,'value'   	=> $params['aname_c30']
                    ,'exwhere'	=> ( $onEdit ) ? 'idCoa != ' . $params['idCoaOld'] . ' AND accountType = ' . $params['accountType'] : 'accountType = ' . $params['accountType']
                )
            )
        ){
            die(
                json_encode(
                    array(
                        'success'   => true 
                        ,'match'    => 2 
                    )
                )
            );
        }

        if( $onEdit ){
            if(
                !_checkData(
                    array(
                        'table'		=> 'coa'
                        ,'field'   	=> 'idCoa'
                        ,'value'   	=> $params['idCoaOld']
                    )
                )
            ){
                die(
                    json_encode(
                        array(
                            'success'   => true
                            ,'match'    => 3 
                        )
                    )
                );
            }

            if( $params['modify'] == 0 ){
                $dateModified = $this->standards->getDateModified( $params['idCoaOld'], 'idCoa', 'coa' );
                if( $params['dateModified'] != $dateModified->dateModified ){
                    die(
                        json_encode(
                            array(
                                'success' => true
                                ,'match' => 4 
                            )
                        )
                    );
                }
            }
        }

        $this->db->trans_begin();
        $params['idCoa']        = $params['mocod_c1'] . $params['chcod_c1'] . $params['accod_c2'] . $params['sucod_c3'];
        $params['new_idCoa']    = $params['idCoa'];
        $idCoa                  = $this->model->saveForm( $params );
        $params['idCoa']        = $idCoa;
        $idCoaHistory           = $this->model->saveFormHistory( $params );
        $params['idCoa']        = $idCoa;

        $this->model->deleteCoaAffiliates( $params );
        foreach( json_decode( $params['coaAffiliate'], true ) as $aff ){
            $aff['idCoa'] = $params['new_idCoa'];
            $this->model->insertCoaAffiliates( $aff );
            $aff['idCoaHistory'] = $idCoaHistory;
            $this->model->insertCoaAffiliatesHistory( $aff );
        }

        if( $this->db->trans_status() === FALSE ){
			$this->db->trans_rollback();
			die(
                json_encode(
                    array(
                        'success' => false
                    )
                )
            );
        }
        else{
			$this->setLogs( $params );
			$this->db->trans_commit();
			die(
                json_encode(
                    array(
                        'success' => true
                        ,'match' => 0
                    )
                )
            );
		}
    }

    public function retrieveData(){
        $params = getData();
		$match  = 0;
		
		if(
            !_checkData(
                array(
                    'table'     => 'coa'
                    ,'field'    => 'idCoa'
                    ,'value'    => $params['idCoa']
                )
            )
        ){
			die( json_encode( array( 'success'=>true, 'match'=>1 ) ) );
        }
        
        $view = $this->model->retrieveData( $params );
        if( $this->model->getRecordsUsed( $params ) ){
			$match = 3;
        }

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                    ,'match'    => $match
                )
            )
        );
    }

    
	public function deleteRecord(){
        $params = getData();
        if(
            !_checkData(
                array(
                    'table'		=> 'coa'
                    ,'field'   	=> 'idCoa'
                    ,'value'   	=> $params['idCoa']
                )
            )
        ){
            die(
                json_encode(
                    array(
                        'success' => true
                        ,'match' => 1 
                    )
                )
            );
        }
        
        if( $this->model->getRecordsUsed( $params ) ){
            die(
                json_encode(
                    array(
                        'success' => true
                        ,'match' => 2 
                    )
                )
            );
        }

        if( $params['accountType'] == 1 ) {
            if( $this->model->checkIfHasSubsidiary( $params ) > 0){
                die(
                    json_encode(
                        array(
                            'success' => true
                            ,'match' => 3
                        )
                    )
                );
            }
        }
			
		$this->db->trans_begin();
        $this->model->delete( $params );
			
		if( $this->db->trans_status() === FALSE ){
			$this->db->trans_rollback();
			die(
                json_encode(
                    array(
                        'success' => false
                    )
                )
            );
		}
		else{
			$this->db->trans_commit();
			$params['deleting'] = true;
			$this->setLogs( $params );
			die(
                json_encode(
                    array(
                        'success' => true
                        ,'match' => 0
                    )
                )
            );
		}
    }
    
    public function getCategoryRecords(){
        $view   = array(
            0   => array(
                'id'    => -1
                ,'name' => 'All'
            )
            ,1  => array(
                'id'    => 1
                ,'name' => 'Regular Account'
            )
            ,2  => array(
                'id'    => 2
                ,'name' => 'Cash Account'
            )
            ,3  => array(
                'id'    => 3
                ,'name' => 'Receivable Account'
            )
            ,4  => array(
                'id'    => 4
                ,'name' => 'Allowance for Bad Debits'
            )
            ,5  => array(
                'id'    => 5
                ,'name' => 'Inventories'
            )
            ,6  => array(
                'id'    => 6
                ,'name' => 'Raw Materials'
            )
            ,7  => array(
                'id'    => 7
                ,'name' => 'Work in Progress'
            )
            ,8  => array(
                'id'    => 8
                ,'name' => 'Finished Goods'
            )
            ,9  => array(
                'id'    => 9
                ,'name' => 'Properties and Equipments'
            )
            ,10  => array(
                'id'    => 10
                ,'name' => 'Accumulated Depreciation'
            )
            ,11  => array(
                'id'    => 11
                ,'name' => 'Accumulated Amortization'
            )
            ,12  => array(
                'id'    => 12
                ,'name' => 'Payable Account'
            )
            ,13  => array(
                'id'    => 13
                ,'name' => 'Cost of Sales'
            )
            ,14  => array(
                'id'    => 14
                ,'name' => 'Sales'
            )
            ,15  => array(
                'id'    => 15
                ,'name' => 'Sales Debits'
            )
            ,16  => array(
                'id'    => 16
                ,'name' => 'Other Income'
            )
            ,17  => array(
                'id'    => 17
                ,'name' => 'Operating Expenses'
            )
            ,18  => array(
                'id'    => 18
                ,'name' => 'Cost of Goods Manufactured'
            )
            ,19  => array(
                'id'    => 19
                ,'name' => 'Purchase Credits'
            )
            ,20  => array(
                'id'    => 20
                ,'name' => 'Direct Labor'
            )
            ,21  => array(
                'id'    => 21
                ,'name' => 'Manufacturing Overhead'
            )
            ,22  => array(
                'id'    => 22
                ,'name' => 'Applied Factory Overhead'
            )
            ,23  => array(
                'id'    => 23
                ,'name' => 'Other Expenses'
            )
            ,24  => array(
                'id'    => 24
                ,'name' => 'Retained Earnings'
            )
            ,25  => array(
                'id'    => 25
                ,'name' => 'Creditable Income Tax'
            )
            ,26  => array(
                'id'    => 26
                ,'name' => 'Capital'
            )
            ,27  => array(
                'id'    => 27
                ,'name' => 'Withdrawals'
            )
            ,28  => array(
                'id'    => 28
                ,'name' => 'Other Assets'
            )
        );
        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    public function processScript(){
        ini_set('max_execution_time', -1);
        $coa            = $this->model->getAllCOA();
        $affiliate      = $this->model->getAllAffiliate();
        $coaaffiliate   = array();
        foreach( $coa as $rs1 ){
            foreach( $affiliate as $rs2 ){
                $coaaffiliate[] = array(
                    'idCoa'         => $rs1['idCoa']
                    ,'idAffiliate'  => $rs2['idAffiliate']
                );
            }
        }
        
        $this->model->truncateDBCoaAffiliate();
        $this->model->saveCoaAffiliate( $coaaffiliate );
    }

    private function setLogs( $params ){
		$header = 'Chart of Accounts : '.$this->USERFULLNAME;
		$action = '';
		
		if( isset( $params['deleting'] ) ){
			$action = 'deleted';
		}
		else{
			if( isset( $params['action'] ) )
				$action = $params['action'];
			else
				$action = ( $params['onEdit'] == 1  ? 'modified' : 'added new' );
		}
		
		setLogs(
            array(
                'actionLogDescription'  => $header . ' ' . $action . ' account code : ' . $params['idCoa'] . '.'
                ,'ident'                => $params['idCoa']
            )
        );
	}
}