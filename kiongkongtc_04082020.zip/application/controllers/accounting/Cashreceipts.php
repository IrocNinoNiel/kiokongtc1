<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Mark Reynor D. Magriña
 * Module: Cashreceipts Module
 * Date: Dec 12, 2019
 * Finished: 
 * Description: 
 * DB Tables: 
 * For Password Hashing, please use password_hash( https://www.php.net/manual/en/function.password-hash.php )
 * */
class Cashreceipts extends CI_Controller {

	public function __construct(){
        parent::__construct();
        setHeader( 'accounting/Cashreceipts_model' );
    }
	
	function getGridListForPayments(){
		$rawData = getData();
		$record = $this->model->getGridListForPayments( $rawData ) ;
		die( json_encode( array( 'success'=>true, 'view'=> $record ) ) );
	}
		
	function getCollectionDetails(){
		$rawData = getData();
		$idInvoice = $rawData['idInvoice'];
		$record = $this->model->getCollectionDetails($rawData);
		die( json_encode( array( 'success'=>true, 'view'=>$record ) ) );
	}
	
	function getBankAccountDetails(){
		$rawData = getData();
		$record = $this->model->getBankAccountDetails($rawData);
		die( json_encode( array( 'success'=>true, 'view'=> $record ) ) );
	}
	function getCashReceiptDetails(){
		$rawData = getData();
		
		
		// print_r($rawData);
		
		// die();
		
		// $record = $this->model->getCashReceiptDetails($rawData);
		$record = $this->model->viewAll($rawData);
		// die( json_encode( array( 'success'=> true, 'total'=> $record['count'], 'view'=>$record[] ) ) );
		
		die( json_encode( array( 'success'=> true, 'total'=> $record['count'], 'view'=> $record['view'] ) ) );
		
	}
	
	function saveCashReceiptsForm(){
		$rawData = getData();
		// $edited = (int)$rawData['onEdit'];
		$rawData['preparedBy'] = $this->session->userdata('USERID');
		$rawData['idLocation'] = $this->session->userdata('LOCATIONID');
		$rawData['pType'] = 1;
		$rawData['pCode'] = $rawData['customer'];
		$rawData['hasJournal'] = 1;
		$rawData['amount'] = (float)$rawData['totalAmountCollected'] + (float)$rawData['discount'];
		$rawData['discount'] = (float)$rawData['discount'];
		// $rawData['idCostCenter'] = $this->session->userdata('idCostCenter');
		
		// print_r($rawData);
		// die();
		
		
		/*   Validation */
		if( $rawData['onEdit'] != 0 ){
			$checkExist = $this->model->checkExist( $rawData['idInvoice'] );
			if ( $checkExist == 0 ) die( json_encode( array( 'success'=> true, 'match'=> 2) ) );
		}
		
		$this->db->trans_begin();// firstline
		$crInvoiceID = $this->model->saveInvoice($rawData);
		
		// echo 'abot ko dre after invoice save';		
		if( (int)$rawData['onEdit'] == 0 ) { $crInvoiceID = $crInvoiceID;}
		else{ $crInvoiceID = (int)$rawData['idInvoice']; }
		
		/* Return the amount to the balance left in invoices and then delete the related records */
		$getReceipts = $this->model->getReceipts($crInvoiceID);
		foreach( $getReceipts as $rs){
			$getBalLeft = $this->model->getBalLeft($rs['fident']);
			$balLeft = ($getBalLeft) ? (float)$getBalLeft->balLeft : 0;
			$this->model->updateBalLeft( $rs['fident'],(float)$rs['amount'] + $balLeft );
		}
		
		/* Delete cash receipt details in receipt and postdated tables */
		$this->model->delReceiptsDetails($crInvoiceID);
		$this->model->delPostdatedDetails($crInvoiceID);
		
		
		/* Prepare receipt details for batch saving */
		$collectionDetails = json_decode( $rawData['collectionDetails'], true );
		if(!empty( $collectionDetails )){
			for( $i=0; $i < count($collectionDetails); $i++ ){
				$collectionDetails[$i]['idInvoice'] = $crInvoiceID;
				$collectionDetails[$i]['idCustomer'] = $rawData['customer'];
				$collectionDetails[$i]['amount'] = $collectionDetails[$i]['collections'];
				$collectionDetails[$i]['fident'] = $collectionDetails[$i]['salesIDInvoice'];
				// $collectionDetails[$i]['fIDModule'] = $rawData['idmodule'];
				unset($collectionDetails[$i]['balance']);
				unset($collectionDetails[$i]['collections']);
				unset($collectionDetails[$i]['receivables']);
				unset($collectionDetails[$i]['reference']);
				unset($collectionDetails[$i]['date']);
				unset($collectionDetails[$i]['selected']);
				
				/* Get current updated balance left */
				$getBalLeft = $this->model->getBalLeft( $collectionDetails[$i]['salesIDInvoice'] );
				$balLeft = ($getBalLeft) ? (float)$getBalLeft->balLeft : 0;
				/* To add validations incase the balance left is zero */
				// to later for the returned items where bal left is not enough to be deducted.
				
				/* Update the invoices balance left */
				$this->model->updateBalLeft( $collectionDetails[$i]['salesIDInvoice'], $balLeft - (float)$collectionDetails[$i]['amount'] );
				unset($collectionDetails[$i]['salesIDInvoice']);
			}
			$this->model->saveCollectionDetails($collectionDetails,$crInvoiceID);
		}
		
		/* Prepare postdated details for batch saving */
		$paymentList = json_decode( $rawData['paymentList'], true );
		for( $i=0; $i < count($paymentList); $i++ ){
			
			$paymentList[$i]['idInvoice'] = $crInvoiceID;
			$paymentList[$i]['paymentMethod'] = $paymentList[$i]['typeID'];
			$paymentList[$i]['status'] = 1;
			unset($paymentList[$i]['type']);
			unset($paymentList[$i]['typeID']);
			unset($paymentList[$i]['bankName']);
			unset($paymentList[$i]['selected']);
		}
		$this->model->savePaymentList($paymentList,$crInvoiceID);
		
		/* Prepare journal entries for batch saving */
		$journalDetails = json_decode( $rawData['journalDetails'], true );
		if( !empty($journalDetails) ){
			for( $i=0; $i < count($journalDetails); $i++ ){
				$journalDetails[$i]['idInvoice'] = $crInvoiceID;
			}
			$this->model->saveJournalDetails($journalDetails,$crInvoiceID);
		}
		
		/* Set Logs */
		if($rawData['onEdit'] == 0){ $actioLog = $this->USERNAME.' added a new cash Receipt transaction'; }
		else{ $actioLog = $this->USERNAME.' edited a transaction'; }	
		setLogs( array(
			'actionLogDescription' => $actioLog
			,'idEu' 	=> $this->USERID
			,'moduleID' => 28
			,'time' 	=> date( "H:i:s A" )
			,'idAffiliate' => $this->AFFILIATEID
		));
		
		if( $this->db->trans_status() === FALSE ){
			$this->db->trans_rollback(); // rollback changes
		}
		else{
			$this->db->trans_commit(); // submit changes
		}
		
		die( json_encode( array( 'success'=>$this->db->trans_status(), 'match'=>0 ) ) );
	}
	
	function deleteCashReceiptRecord(){
		$rawData = getData();
		$match = 0;
		
		// print_r($rawData);
		// die();
		
		/* Return the amount to the balance left in invoices and then delete the related records */
		$getReceipts = $this->model->getReceipts($rawData['idInvoice']);
		foreach( $getReceipts as $rs){
			$getBalLeft = $this->model->getBalLeft($rs['fident']);
			$balLeft = ($getBalLeft) ? (float)$getBalLeft->balLeft : 0;
			$this->model->updateBalLeft( $rs['fident'],(float)$rs['amount'] + $balLeft );
		}		
		
		$this->model->deleteCashReceipt($rawData['idInvoice']);
		$this->model->delReceiptsDetails($rawData['idInvoice']);
		$this->model->delPostdatedDetails($rawData['idInvoice']);
		
		setLogs( array(
			'actionLogDescription' => $this->USERNAME.' deleted a transaction'
			,'idEu' => $this->USERID
			,'moduleID' => 28
			,'time' => date("H:i:s A")
		));
		die( json_encode( array( 'success'=>true, 'match'=> $match ) ) );
	}
	
	function retrieveData(){
		$rawData = getData();
		$match = 0;
		$idInvoice = $rawData['idInvoice'];
		$record = $this->model->retrieveData($idInvoice);
		die( json_encode( array( 'success'=>true, 'match'=> $match, 'view'=> $record ) ) );
	}
	

}