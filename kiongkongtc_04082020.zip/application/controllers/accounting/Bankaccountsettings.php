<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Bankaccountsettings extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        setHeader('accounting/Bankaccountsettings_model');
    }

    public function getBanks()
    {
        $view = $this->model->getBanks();

        array_unshift( $view, array(
            'id' => 0
            ,'name' => 'Add New Bank'
        ));

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    public function getCoa()
    {
        $params = getData();
        $view   = $this->model->getCoa( $params );

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    public function getBankAccounts()
    {
        $params = getData();
        $view   = $this->model->getBankAccounts( $params );

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    public function retrieveData()
    {
        $match              = 0;
        $params             = getData();
        $view               = $this->model->retrieveData( $params );
        $checkIfUsed        = $this->model->checkIfUsed( $params['idBankAccount'] );
        $checkIfNotFound    = $this->model->checkIfNotFound( $params['idBankAccount'] );

        if ( $checkIfNotFound ) { $match = 1; }
        if ( $checkIfUsed ) { $match = 2; }

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'match'    => $match
                    ,'view'     => $view
                )
            )
        );
    }

    public function saveBankAccount()
    {
        $params = getData();

        // SAVING TRANS START
        $this->db->trans_begin();
            // EDIT
            if ( $params['idBankAccount'] > 0 ) {
                $this->model->updateBankAccount( $params , $params['idBankAccount'] );
                $this->model->saveBankAccountHistory( $params , $params['idBankAccount'] );
                $params['action']   = 'edited the bank account of';
            } else {
                // SAVE
                if ( $this->model->checkDuplicaiton( $params ) ) {
                    die(
                        json_encode(
                            array(
                                'success' => true
                                ,'match'  => 1
                            )
                        )
                    );
                }

                $idBankAccount  = $this->model->saveBankAccount( $params );
                $this->model->saveBankAccountHistory( $params , $idBankAccount );
                $params['action']   = 'added a new bank account for';
            }


        if( $this->db->trans_status() === FALSE ){
            $this->db->trans_rollback();
            die(
                json_encode(
                    array(
                        'success' => false
                    )
                )
            );
        }

        else {
            $this->db->trans_commit();
            $this->setLogs( $params );
            die(
                json_encode(
                    array(
                        'success' => true
                        ,'match'  => 0
                    )
                )
            );
        }
    }

    public function archiveBankAccount()
    {
        $match              = 0;
        $params             = getData();
        $checkIfUsed        = $this->model->checkIfUsed( $params['idBankAccount'] );
        $checkIfNotFound    = $this->model->checkIfNotFound( $params['idBankAccount'] );
        
        if ( $checkIfNotFound ) { $match = 1; }
        if ( $checkIfUsed ) { $match = 2; }
        else {
            $this->model->archiveBankAccount( $params['idBankAccount'] );
            $params['action']   = 'deleted the bank account of';
            $this->setLogs( $params );
        }

        die(
            json_encode(
                array(
                    'success'   => true
                    ,'match'    => $match
                    ,'params'   => $params
                )
            )
        );
    }

    public function searchGrid()
    {
        $params = getData();
        $view = $this->model->searchGrid( $params );

        die(
            json_encode(
                array(
                    'success' => true 
                    ,'view' => $view
                )
            )
        );
    }

    private function setLogs( $params ){
        $header = 'Bank Account Settings : '.$this->USERFULLNAME;
        $action = '';
        
        if( isset( $params['deleting'] ) ){
            $action = 'deleted the bank account of';
        }
        else{
            if( isset( $params['action'] ) )
                $action = $params['action'];
            else
                $action = ( $params['onEdit'] == 1  ? 'modified' : 'added new' );
        }
        
        setLogs(
            array(
                'actionLogDescription'  => $header . ' ' . $action . ' ' . $params['coaName']
            )
        );
    }
}
