<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Vouchersreceivable extends CI_Controller
{
    public function __Construct()
    {
        parent::__Construct();
        setHeader( 'accounting/Vouchersreceivable_model' );
    }

    public function getCustomers()
    {
        $params = getData();
        $view = $this->model->getCustomers( $params );

        die(
            json_encode(
                array(
                    'success' => true 
                    ,'view' => $view
                )
            )
        );
    }

    public function save_VouchersReceivable()
    {
        $params = getData();
        $idInvoice = 0;

        if ( $this->model->isClosedJE( $params ) > 0 ) { 
            die(
                json_encode(
                    array(
                        'success' => true
                        ,'match'  => 4
                    )
                )
            );
        }
            
        $this->db->trans_begin();

        if ( $params['onEdit'] == 1 ) {
            $idInvoice = $params['idInvoice'];
            $this->model->update_Invoice_VouchersReceivable( $params );
            $this->model->delete_Journal_VouchersReceivable( $idInvoice );
            $params['action']   = 'edited a transaction.';
        }

        else {
            $idInvoice = $this->model->save_Invoice_VouchersReceivable( $params );
            $params['action']   = 'added a new Vouchers Receivable Transaction.';
        }

        $this->model->save_InvoiceHistory_VouchersReceivable( $params , $idInvoice );
        if ( $params['jeLength'] > 1 ) $this->model->save_JournalHistory_VouchersReceivable( $params , $idInvoice );

        if( $this->db->trans_status() === FALSE ){
            $this->db->trans_rollback();
            die(
                json_encode(
                    array(
                        'success' => false
                    )
                )
            );
        }

        else {
            $this->db->trans_commit();
            $this->setLogs( $params );
            
            die(
                json_encode(
                    array(
                        'success' => true
                        ,'match'  => 0
                    )
                )
            );
        }
    }

    public function getVouchersReceivable()
    {
        $params = getData();
        $view = $this->model->viewAll( $params );

        die(
            json_encode(
                array(
                    'success' => true 
                    ,'view' => $view
                )
            )
        );
    }

    public function searchHistoryGrid()
    {
        $params = getData();
        $view = $this->model->searchHistoryGrid( $params );

        die(
            json_encode(
                array(
                    'success' => true 
                    ,'view' => $view
                )
            )
        );
    }

    public function retrieveData()
    {
        $match           = 0;
        $params          = getData();
        $view            = $this->model->retrieveData( $params['idInvoice'] );
        $checkIfUsed     = $this->model->checkIfUsed( $params['idInvoice'] );
        $checkIfNotFound = $this->model->checkIfNotFound( $params['idInvoice'] );

        if ( $checkIfNotFound ) { $match = 1; }
        if ( $checkIfUsed > 0 ) { $match = 2; }

        die(
            json_encode(
                array(
                    'success' => true
                    ,'match'  => $match
                    ,'view'   => $view
                )
            )
        );
    }

    public function archiveInvoice()
    {
        $match              = 0;
        $params             = getData();
        $checkIfUsed        = $this->model->checkIfUsed( $this->input->post( 'idInvoice' )  );
        $checkIfNotFound    = $this->model->checkIfNotFound( $this->input->post( 'idInvoice' ) );
        
        if ( $checkIfNotFound ) { $match = 1; }
        if ( $checkIfUsed > 0 ) { $match = 2; } 
        else {
            $this->model->archiveInvoice( $this->input->post( 'idInvoice' ) );
            $params['action']   = 'deleted a transaction.';
            $this->setLogs( $params );
        }

        die(
            json_encode(
                array(
                    'success' => true
                    ,'match' => $match
                )
            )
        );
    }

    private function setLogs( $params ){
        $header = 'Vouchers Receivable : '.$this->USERFULLNAME;
        $action = '';
        
        if( isset( $params['deleting'] ) ){
            $action = 'deleted a transaction';
        }
        else{
            if( isset( $params['action'] ) )
                $action = $params['action'];
            else
                $action = ( $params['onEdit'] == 1  ? 'modified' : 'added new' );
        }
        
        setLogs(
            array(
                'actionLogDescription'  => $header . ' ' . $action
                ,'idReference'			=> $params['idReference']
                ,'referenceNum'			=> $params['referenceNum']
                ,'idModule'				=> $params['idmodule']
            )
        );
    }
}
