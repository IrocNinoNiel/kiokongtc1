<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/** Home Module
  * [Developer]
  * Developer: Jayson Dagulo
  * Date Start: 10-11-2019
  * Date Ended: 
  
  * [Database]
  * [Description]
  * 
 * [Modification]
 **/

class Home extends CI_Controller {

	public function __construct(){
		parent::__construct();
		setHeader('Home_model');
	}
	
	public function index(){
		header( "cache-Control: no-store, no-cache, must-revalidate" );
		header( "cache-Control: post-check=0, pre-check=0", FALSE );
		
		header( "Pragma: no-cache" );
		header( "Expires: Sat, 26 Jul 1997 05:00:00 GMT" );		
		
		$this->checklog();
		$data = $this->model->getCompany();
		$affiliateData = $this->model->getAllAffiliate();
		
		$this->load->view( 'login_view', array( 'comp' => $data, 'affiliate' => $affiliateData ) );
	}
	public function loginUser( ){
        $data      = getData( FALSE );
		$loginUser = $this->model->loginUser( $data );
		
		// print_r($data);
		// print_r($loginUser);
		
		// Die('test enter');
		// echo('Trigger 5');
		
		if( empty($loginUser) ){
			// echo('Trigger 1');
			Die( json_encode( array( 'trigger'=> 1, 'success' => true ) )  );
		}
		// else if( ! empty( $loginUser->module_count ) && $loginUser->module_count == 0 ){
		else if( $loginUser->module_count == 0 ){
			// if( $loginUser->module_count == 0 ){
				// echo('Trigger 2');
				die( json_encode( array( 'trigger' => 2 ,'success' => true ) ) );
			// }
		}
		// else if( ! empty( $loginUser->affiliate_count ) && $loginUser->affiliate_count == 0 ){
		else if( $loginUser->affiliate_count == 0 ){
			// if( $loginUser->affiliate_count == 0  ){
				// echo('Trigger 3');
				die( json_encode( array( 'trigger'=> 3, 'success'=> true ) ) );
			// }
		}
		else if( $loginUser->employeeStatus == 1 ){
			// if( $loginUser->affiliate_count == 0  ){
				// echo('Trigger 3');
				die( json_encode( array( 'trigger'=> 4, 'success'=> true ) ) );
			// }
		}
		else{

		// 	else if( $loginUser->statusAffiliate == 0 && $loginUser->userTypeID != 0 ){
		// 		die(json_encode(
		// 			array(
		// 				'trigger' => 3
		// 				,'success' => true
		// 			)
		// 		));
		// 	}else{
			// echo('Trigger 0');
			// echo('abot pod bya dre 2');
			
				if( isset( $_SERVER['SERVER_SOFTWARE'] ) && strpos( $_SERVER['SERVER_SOFTWARE'], 'Google App Engine' ) !== FALSE ){
					$printPath  = 'gs://zealep1/';
					$logoPath 	= "gs://zealep1/images/logo/";
					$server 	= 1;
				}
				else{
					$printPath  = site_url();
					$logoPath	= site_url().LOGO_PATH;
					$server 	= 0;
				}

				// echo('abot pod bya dre 1');
				$this->session->set_userdata(
					array(
						'logged_in' => TRUE
						,'INITHEADER' => FALSE
						,'USERID' => $loginUser->userID
						,'EMPLOYEEID' => $loginUser->empID
						// ,'USERID' => 1
						// ,'USERID' => 59
						,'USERFULLNAME' => $loginUser->name
						// ,'USERFULLNAME' => 'User Full Name'
						,'USERNAME' => $loginUser->userName
						// ,'USERNAME' => 'Username'
						,'USERTYPEID' => $loginUser->userTypeID
						// ,'USERTYPEID' => 0
						,'USERTYPENAME'	=> $loginUser->userTypeName
						// ,'USERTYPENAME'	=> 'Super Admin'
						,'AFFILIATEID' => $loginUser->idAffiliate
						// ,'IDAFFILIATE' => 1
						,'AFFILIATENAME' => $loginUser->affiliateName
						// ,'AFFILIATENAME' => 'Affiliate Name'
						,'AFFILIATETAGLINE' => $loginUser->affiliateTagLine
						// ,'AFFILIATETAGLINE' => 'Tag Line'
						,'AFFILIATEREFTAG' => $loginUser->reftag
						// ,'AFFILIATEREFTAG' => '1'
						,'ISAPPROVER' => 1
						,'AFFILIATEDATESTART' => $loginUser->dateStart
						,'AFFILIATEACCSCHED' => $loginUser->affiliateAccSched
						// ,'AFFILIATEMONTH' => $loginUser->affiliateMonth
						,'ISMAIN' => $loginUser->maintag
						// ,'ISCURRENTMAIN' => $loginUser->maintag
						// ,'COMPANYNAME' => $loginUser->companyName
						// ,'SYSTEMNAME' => $loginUser->systemName
						,'SYSTEMNAME' => 'Kiokong Trucking and Construction Accouting System'
						// ,'COMPLOGO' => (is_url_exist($logoPath.$loginUser->companyLogo) ? $loginUser->companyLogo : DEFAULT_EMPTY_IMG)
						,'COMPLOGO' => DEFAULT_EMPTY_IMG
						// ,'DEFAULT_COMPLOGO' => (is_url_exist($logoPath.$loginUser->default_companyLogo) ? $loginUser->default_companyLogo : DEFAULT_EMPTY_IMG)
						,'DEFAULT_COMPLOGO' => DEFAULT_EMPTY_IMG
						,'LOCATIONID' => '3'
						// ,'PRINTPATH' => $printPath
						,'LOGOPATH' => $logoPath
						// ,'ISGAE' => $server
					)
				);
		
				// echo('abot pod bya dre');
				die( json_encode( array( 'trigger' => 0 ,'success'	=> true ) ) );
				
				// die ( json_encode ( array ( 'success'=>true, 'match'=> 0 ) ) );
		}
		// 		}
		// 	}
		// }
		// else{
		// 	die(json_encode(
		// 		array(
		// 			'trigger' => 1
		// 			,'success' => true
		// 		)
		// 	));
		// }
    }
	
	public function redirurl(){
		
		// die('ni abot dre kay');
		
		redirect('mainview');
	}
	
	public function checklog(){
		$logged_in = $this->session->userdata('logged_in');
		if(isset($logged_in) && $logged_in === TRUE){
			redirect('mainview');
		}
	}
	
	public function logout( $proc = 0 ){
		if( $proc == 1 ){
			$logs[ 'idEu' ] = getsession( 'USERID' );
			$logs[ 'actionLogDescription' ] = getsession( 'USERNAME' ) . ' has logged out of the system.';
			$this->saveLogs( $logs );

			$this->session->sess_destroy();
			redirect( '' );
		}
		else{
			redirect( '' );
		}
    }
	
	public function autoLogout(){
		$this->session->sess_destroy();
		setLogs( array(
			'actionLogDescription'	=> getsession( 'USERNAME' ) . ' has logged out of the system.'
			,'idEu' 				=> getsession( 'USERID' )
		) );
		die(
			json_encode(
				array(
					'success' => TRUE
				)
			)
		);
	}
	
	public function checkIfLogin(){
		$login = 0;
		if($this->session->userdata('logged_in') == 1){
			$login = 1;
		}
		die(
			json_encode(
				array(
					'success' => true
					,'login' => $login
				)
			)
		);
	}

	private function saveLogs( $data )
	{
		$data[ 'moduleID' ] = null;
		setLogs( $data );
	}

	public function getAffiliateByUser(){
		$data      		= getData( FALSE );
		$affiliateData 	= $this->model->getAffiliateByusername( $data['username'] );
		
		// print_r( $affiliateData );
		
		// echo count($affiliateData);
		// die();
		
		if( count($affiliateData) == 0 ){
			$affiliateData = 0;
		}
		
		
		echo json_encode($affiliateData);
		die;
	}

	public function getAffiliate(){
		//$affiliateData = $this->model->getAffiliateByusername( $data['username'] );
		$affiliateData = $this->model->getAllAffiliate();
		echo json_encode(['data' => $affiliateData]);
		die;
	}
	
	public function checkAffiliate(){
		// checkAffiliate
	}
}