<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Hazel Alegbeleye
 * Module: Bank Settings
 * Date: Dec 3, 2019
 * Finished: December 3, 2019
 * Description: This module allows the authorized user to set (add, edit and delete) a bank
 * DB Tables: bank, bankaccount
 * */ 
class Banksettings extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'generalsettings/Banksettings_model' );
    }

    function getBanks() {
        $params = getData();
        $view = $this->model->getBanks( $params );

        die(
            json_encode(
                array(
                    'succes' => true
                    ,'view' => $view['view']
                    ,'total' => $view['count']
                )
            )
        );
    }

    function retrieveData() {
        $params = getData();
        $view = $this->model->retrieveData( $params );

        die(
            json_encode(
                array(
                    'succes' => true
                    ,'view' => $view
                )
            )
        );
    }

    function saveBank() {
        $params = getData();
        $view = $this->model->saveBank( $params );

        $msg = ( $params['onEdit'] ) ? ' edited the bank ': ' added a new bank ';

        setLogs(
            array(
                'actionLogDescription' => $this->USERNAME . $msg . $params['bankName']
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 14
                ,'time'                => date("H:i:s A")
            )
        );

        die(
            json_encode(
                array(
                    'succes' => true
                    ,'view' => $view
                )
            )
        );
    }

    function deleteBank() {
        $params = getData();
        $match = $this->model->deleteBank( $params );

        setLogs(
            array(
                'actionLogDescription' => $this->USERNAME . ' deleted a bank.'
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 14
                ,'time'                => date("H:i:s A")
            )
        );

        die(
            json_encode(
                array(
                    'succes' => true
                    ,'match' => $match
                )
            )
        );
    }
}