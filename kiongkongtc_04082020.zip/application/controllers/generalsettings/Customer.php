<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'generalsettings/Customer_model' );
    }

    function getAffiliates() {
        $params = getData();
        $view = $this->model->getAffiliates( $params );

        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view['view']
					,'total' => $view['count']
				)
			)
        );
    }

    function getCoa(){
        $params = getData();
        $view = $this->model->getCoa( $params );
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view['view']
					,'total' => $view['count']
				)
			)
        );
    }

    function getItems(){
        $params = getData();
        $view = $this->model->getItems( $params );

        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view['view']
					,'total' => $view['count']
				)
			)
        );
    }

    function getCustomerItem(){
        $params = getData();
        $view = $this->model->getCustomerItem( $params );

        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view['view']
					,'total' => $view['count']
				)
			)
        );
    }

    function saveForm(){
        $params = getData();
        $match = 0;

        /* Saving Customer */
        $idCustomer = $this->model->saveCustomer( $params );
        

        /* Saving Customer History */
        $params['idCustomer'] = $idCustomer;
        $idCustomerHistory = $this->model->saveCustomerHistory( unsetParams( $params, 'customer' ) );

        if( $idCustomer !== NULL) {
            /* Saving items, affiliates, and contacts if not empty. */

            #AFFILIATES
            $custAffiliates = [];
            $custAffiliatesHis = [];
            $params['affiliates'] = json_decode( $params['affiliates'] );


            if( !empty( $params['affiliates']) ) {
                $this->model->deleteCustomerDetails( 'customeraffiliate', $idCustomer );

                foreach( $params['affiliates'] as $affiliate ){
                    $affiliate = (array)$affiliate;

                    /* Saving for Customer Affiliates */
                    $affiliate['idCustomer'] = $idCustomer;
                    $affiliate = unsetParams( $affiliate, 'customeraffiliate' );

                     /* Saving for Customer Affiliates History */
                    $affiliateHistory = $affiliate;
                    $affiliateHistory['idCustomerHistory'] = $idCustomerHistory;

                    /* Insert Affiliate & retrieve ID here */
                    $idCustomerAffiliate = $this->model->saveCustomerAffiliates( $affiliate );

                    /* Insert Affiliate history here */
                    $affiliateHistory['idCustomerAffiliate'] = $idCustomerAffiliate;

                    array_push( $custAffiliatesHis, $affiliateHistory );
                }

                $this->model->saveCustomerAffiliatesHistory( $custAffiliatesHis );
            }

            
            
            #ITEMS 
            $custItems = [];
            $custItemsHis = [];
            $params['items'] = json_decode( $params['items'] );

            if( !empty( $params['items'] ) ){
                $this->model->deleteCustomerDetails( 'customeritems', $idCustomer );

                foreach( $params['items'] as $item ){
                    $item = (array)$item;

                     /* Saving for Customer Items */
                    $item['idCustomer'] = $idCustomer;
                    $item = unsetParams( $item, 'customeritems' );

                     /* Saving for Customer Items History */
                    $itemHistory = $item;
                    $itemHistory['idCustomerHistory'] = $idCustomerHistory;
                    
                    array_push( $custItems, $item );
                    array_push( $custItemsHis, $itemHistory );
                }

                $custItems['idCustomer'] = $idCustomer;
                $this->model->saveCustomerItems( $custItems, $custItemsHis );
            }

            #CONTACTS 
            $custContacts = [];
            $custContactsHis = [];
            $params['contacts'] = json_decode( $params['contacts'] );

            if( !empty( $params['contacts'] ) ){
                $this->model->deleteCustomerDetails( 'custcontactperson', $idCustomer );

                foreach( $params['contacts'] as $contact ){
                    $contact = (array)$contact;

                    /* Saving for Customer Contacts */
                    $contact['idCustomer'] = $idCustomer;
                    $contact = unsetParams( $contact, 'custcontactperson' );

                    /* Saving for Customer Contacts History */
                    $contactHistory = $contact;
                    $contactHistory['idCustomerHistory'] = $idCustomerHistory;

                    array_push( $custContacts, $contact );
                    array_push( $custContactsHis, $contactHistory );
                }
                $custContacts['idCustomer'] = $idCustomer;
                $this->model->saveCustomerContacts( $custContacts, $custContactsHis );
            }

            $msg = ( $params['onEdit'] ) ? ' edited the customer details of ' : ' added a new customer ';

            setLogs(
                array(
                    'actionLogDescription' => $this->USERNAME . $msg . $params['name']
                    ,'idEu'                => $this->USERID
                    ,'moduleID'            => 11
                    ,'time'                => date("H:i:s A")
                )
            );


            /* Checking for values  */

            // echo 'AFFILIATES </br>';
            // print_r( $custAffiliates );
            // echo '== </br>';
            // print_r( $custAffiliatesHis );
            // echo '</br> ITEMS </br>';
            // print_r( $custItems );
            // echo '== </br>';
            // print_r( $custItemsHis );
            // echo '</br> CONTACTS </br>';
            // print_r( $custContacts );
            // echo '== </br>';
            // print_r( $custContactsHis );

        } else {
            $match = 1;
        }
    

        die(
            json_encode(
                array(
                    'success' => true
                    ,'match' => $match
                )
            )
        );
    }

    function saveCustomerAffiliate(){
        $params = getData();
        $view = $this->model->saveCustomerAffiliate( $params );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    function saveCustomerItem() {
        $params = getData();
        $view = $this->model->saveCustomerItem( json_decode( $params['data'], true ), $params['idCustomer'] );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                    ,'match' => ( $view != '' > 0 ? 1 : 0  ) 
                )
            )
        );
    }

    function getCustomers() {
        $params = getData();
        $view = $this->model->getCustomers( $params );

        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view['view']
					,'total' => $view['count']
				)
			)
        );
    }

    function retrieveData(){
        $params = getData();
        $view = $this->model->retrieveData( $params );

        // LQ();

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    function deleteCustomer(){
        $params = getData();
        $view = $this->model->deleteCustomer( $params );
        $customerName = $this->model->retrieveData( $params );

        setLogs(
            array(
                'actionLogDescription' => $this->USERNAME . ' deleted a customer ' . $customerName[0]['name']
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 11
                ,'time'                => date("H:i:s A")
            )
        );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    function deleteItem(){
        $params = getData();
        // $this->model->deleteItem( $params );

        $data = json_decode( $params['data'], true);

        die(
            json_encode(
                array(
                    'success' => true
                    ,'data' => $data
                )
            )
        );
    }

    function getContacts(){
        $params = getData();
        $view = $this->model->getContacts( $params );

        // LQ();

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }
}