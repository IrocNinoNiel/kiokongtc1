<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Salesorder extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'inventory/Salesorder_model' );
        $this->load->model('standards/Standards2_model', 'standard2');
    }

    public function getCustomerItem(){
        $params = getData();
        $view  = $this->model->getCustomerItem($params);
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
        );
    }

    public function getItems(){
        $params = getData();
        $view = $this->model->getItems($params);
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
        );
    }

    public function getCustomerDetails(){
        $params = getData();
        $view = $this->model->getCustomerDetails($params);
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
        );
    }

    public function save(){
        $this->db->trans_start();
        $params = getData();

        if ( $this->model->isClosedJE( $params ) > 0 ) { 
			die(
				json_encode(
					array(
						'success' => true
						,'match'  => 4
					)
				)
			);
        }
        
        $params['items'] = json_decode($params['items'], true);
        $params['journals'] = json_decode($params['journals'], true);
        $invoice = [
            "idAffiliate" => $params["idAffiliate"],
            "idReference" => $params["idReference"],
            "idCostCenter" => $params["idCostCenter"],
            "referenceNum" => $params["referenceNum"],
            "idReferenceSeries" => $params["idReferenceSeries"],
            "idModule" => $params["idmodule"],
            "cancelTag" => $params["cancelTag"],
            "idLocation" => $this->session->userdata('LOCATIONID'),
            "date" => $params["tdate"]." ".$params["ttime"],
            "pickupDate" => $params["pickupdate"]." ".$params["pickuptime"],
            "pType" => 1,
            "pCode" => $params["pCode"],
            "amount" => $params["totalamt"],
            "remarks" => $params["remarks"],
            "dateModified" => $params["dateModified"],
            "hasJournal" => (count($params["journals"]) > 0),
            "preparedBy" => $this->session->userdata('USERID'),
            'status' => APPROVED
        ];
        if($params['idInvoice'] != NULL){
			$params['action']   = 'edited a transaction';
            $id = $params['idInvoice'];
            $this->model->update($invoice, 'invoices', $id);
            $this->model->deleteAssociateChild(['id'=>$id]);

        }else{
			$params['action']   = 'added a new Sales Order transaction';
            $id = $this->model->insert($invoice, 'invoices'); 
        }
        
        $invoice['idInvoice'] = $id;
		$this->model->insert($invoice, 'invoiceshistory');
        $data = $this->format($params, $id);

        $this->model->insertBulk($data['items'], 'so');
        if(count($data['journals']) > 0){
            $this->model->insertBulk($data['journals'], 'posting');
        }

        if ($this->db->trans_status() === FALSE) {
			$this->db->trans_rollback();
			die(
				json_encode(
					array(
						'success' => false
					)
				)
			);
		} 
		else {
            $this->db->trans_commit();
            $this->setLogs( $params );
			die(
				json_encode(
					array(
						'success' => true
					)
				)
			);
		}
    }

    private function format($data, $invoice){
        $items = [];
        $journals = [];

        $data['idLocation'] =  $this->session->userdata('LOCATIONID');
        $data['preparedBy'] =  $this->session->userdata('USERID');

        foreach($data['items'] as $key => $item){
            array_push($items, [
                'idItem' => $item['id'],
                'qty' =>  $item['qty'],
                'qtyLeft' =>  $item['qty'],
                'cost' => $item['cost'],
                'idInvoice' => $invoice
            ]);
        }

        foreach($data['journals'] as $key => $journal){
            array_push($journals, [
                'idInvoice' => $invoice,
                'explanation' =>  $journal['explanation'],
                'idCoa' =>  $journal['idCoa'],
                'idCostCenter' =>  $journal['idCostCenter'],
                'debit' =>  $journal['debit'],
                'credit' =>  $journal['credit'],
                'idSo' => 0
            ]);
        }

        return['items' => $items, 'journals' => $journals];
    }

    public function getSoItems(){
        $params = getData();
        $data = $this->model->viewAll($params);

        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $data['view']
					,'total' => $data['count']
				)
			)
        );
    }

    public function delete(){
        $params = getData();
        $match = $this->model->checkMutation('so', ['so.idInvoice'=>$params['id']])[0]['state'];

        //cancelTag
        if ( (int)$this->model->cancelTag( $params['id'] ) == 1 ) {
            $match = 2;
        }
        
        if($match == IS_MUTABLE){
            $this->model->update( ['archived' => POSITIVE], 'invoices',$params['id']);

			$params['action']   = 'deleted a transaction';
            $this->setLogs( $params );
        }
        die(
			json_encode(
				array(
                    'success' => true
                    ,'match' => (int)$match
				)
			)
        );
    }

    public function retrieve(){
        $params = getData();
        $view = $this->model->retrieveAll($params);
        $match = $this->model->checkMutation('so', ['so.idInvoice'=>$params['id']])[0]['state'];


        //cancelTag
        if ( (int)$this->model->cancelTag( $params['id'] ) == 1 ) {
            $match = 2;
        }

        die(
			json_encode(
				array(
                    'success' => true
                    ,'view' => json_encode($view)
                    ,'match' => (int) $match
				)
			)
        );
    }
    public function getSearchRef(){
        $params = getData();
        $view   = $this->model->getSearchRef( $params );
        array_unshift(
            $view
            ,array(
                'id'     => 0
                ,'name'    => 'All'
            )
        );
        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    private function setLogs( $params ){
		$header = 'Sales Order : '.$this->USERFULLNAME;
		$action = '';
		
		if( isset( $params['deleting'] ) ){
			$action = 'deleted a transaction';
		}
		else{
			if( isset( $params['action'] ) )
				$action = $params['action'];
			else
				$action = ( $params['onEdit'] == 1  ? 'modified' : 'added new' );
		}
		
		setLogs(
            array(
                'actionLogDescription'  => $header . ' ' . $action
                ,'idReference'			=> $params['idReference']
                ,'referenceNum'			=> $params['referenceNum']
                ,'idModule'				=> $params['idmodule']
            )
        );
    }
}