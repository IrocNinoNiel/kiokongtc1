<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Salessummary extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'inventory/Salessummary_model' );
    }

    public function getCustomer(){
        $params = getData();
        $view  = $this->model->getCustomer($params);
        array_unshift($view, ['id'=>0,'name'=>'All']);
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
        );
    }
    
    public function getSalesReference(){
        $params = getData();
        $view = $this->model->getSalesReference($params);
        array_unshift($view, ['id'=>0,'name'=>'All']);
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
        );
    }

    public function getSales(){
        $params = getData();
        $view = $this->model->getSales($params);
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
        );
    }

    public function getSalesReturn(){
        $params = getData();
        $view = $this->model->getSalesReturn($params);

        setLogs(
            array(
                'actionLogDescription' => $this->USERFULLNAME . ' Generates Sales Summary Report'
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 24
                ,'time'                => date('H:i:s A')
            )
        );

        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
        );
    }

    public function printPDF(){
        $params = getData();
        $sales = $this->model->getSales($params);
        $return = $this->model->getSalesReturn($params);
        $total_net_sale = array_sum(array_column($sales, 'amount'));
        $total_return_amount = array_sum(array_column($return, 'amount'));
        $overall_net_sales = $total_net_sale - $total_return_amount;

        $header = [
            'title' => 'Sales Summary'
            ,'file_name' => 'Sales Summary'
            ,'folder_name' => 'pdf/inventory/'
            ,'addPage' => true
            ,'table_title' => 'Sales'
            ,'orientation' => 'L'
        ];

        $col_sales = [
            $this->pdfColFormat('Cost Center', 'costcenter', '10%'),
            $this->pdfColFormat('Date', 'date', '10%'),
            $this->pdfColFormat('Reference', 'reference', '7%'),
            $this->pdfColFormat('Customer', 'customer', '12%'),
            $this->pdfColFormat('Sales Amount', 'sales', '7%', 'numbercolumn'),
            $this->pdfColFormat('Vat Amount', 'vat', '7%', 'numbercolumn'),
            $this->pdfColFormat('Sales with VAT', 'withvat', '7%', 'numbercolumn'),
            $this->pdfColFormat('Discount', 'discount', '7%', 'numbercolumn'),
            $this->pdfColFormat('Net Sales', 'amount', '7%', 'numbercolumn'),
            $this->pdfColFormat('Status', 'status', '7%'),
            $this->pdfColFormat('Salesman/Cashier', 'salesman', '12%'),
            $this->pdfColFormat('VAT Type', 'vattype', '7%')
        ];
        // add total in sales
        
        array_push($sales, [
            'costcenter' => ''
            ,'date' => ''
            ,'reference' => ''
            ,'customer' => ''
            ,'sales' => array_sum(array_column($sales, 'sales'))
            ,'vat' => array_sum(array_column($sales, 'vat'))
            ,'withvat' => array_sum(array_column($sales, 'withvat'))
            ,'discount' => array_sum(array_column($sales, 'discount'))
            ,'amount' => $total_net_sale
            ,'status' => ''
            ,'salesman' => ''
            ,'vattype' => ''
        ]);
        $col_return = [
            $this->pdfColFormat('Cost Center', 'costcenter', '15%'),
            $this->pdfColFormat('Date', 'date', '15%'),
            $this->pdfColFormat('Sales Reference', 'salereference', '10%'),
            $this->pdfColFormat('Sales Return Reference', 'salereturnreference', '10%'),
            $this->pdfColFormat('Customer', 'customer', '20%'),
            $this->pdfColFormat('Amount', 'amount', '10%'),
            $this->pdfColFormat('Salesman', 'salesman', '20%')
        ];
        // add total in sales return
        
        array_push($return, [
            'costcenter' => ''
            ,'date' => ''
            ,'salereference' => ''
            ,'salereturnreference' => ''
            ,'customer' => ''
            ,'amount' =>  $total_return_amount
            ,'salesman' => ''
        ]);

        $col_overall_total = [
            'totalNetSales' => number_format($overall_net_sales,2,'.',','),
        ];

        $head = generate_table_as_string($header, $col_sales , $sales);
        $header['table_title'] = 'Sales Return';
        $head .= generate_table_as_string($header, $col_return , $return);
        $header['table_hidden'] = TRUE;
        setLogs(
            array(
                'actionLogDescription' => $this->USERFULLNAME . ' Exported the generated Sales Summary Report (PDF)'
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 24
                ,'time'                => date('H:i:s A')
            )
        );
		generate_table( $header, $col_overall_total, [], $head);

    }

    function printExcel(){
        $params = getData();
        $sales = $this->model->getSales($params);
        $return = $this->model->getSalesReturn($params);
        $total_net_sale = array_sum(array_column($sales, 'amount'));
        $total_return_amount = array_sum(array_column($return, 'amount'));
        $overall_net_sales = $total_net_sale - $total_return_amount;
        array_push($sales,[
            'costcenter' => ''
            ,'date' => ''
            ,'reference' => ''
            ,'customer' => ''
            ,'sales' => array_sum(array_column($sales, 'sales'))
            ,'vat' => array_sum(array_column($sales, 'vat'))
            ,'withvat' => array_sum(array_column($sales, 'withvat'))
            ,'discount' => array_sum(array_column($sales, 'discount'))
            ,'amount' => $total_net_sale
            ,'status' => ''
            ,'salesman' => ''
            ,'vattype' => ''
        ]);


        array_push($return, [
            'costcenter' => ''
            ,'date' => ''
            ,'salereference' => ''
            ,'salereturnreference' => ''
            ,'customer' => ''
            ,'amount' =>  $total_return_amount
            ,'salesman' => ''
        ]);


        $csvarray = [
            [ 'title',  $params['title']],
            [ 'Affiliate',  $params['pdf_idAffiliate']],
            [ 'Cost Center',  $params['pdf_idCostCenter']],
            [ 'Customer',  $params['pdf_customer']],
            [ 'Payment Method',  $params['pdf_payment']],
            [ 'VAT Type',  $params['pdf_vat']],
            [ 'Sales Reference',  $params['pdf_reference']],
            [ 'Date',  "{$params['pdf_datefrom']} {$params['timeFrom']} to {$params['pdf_dateto']} {$params['timeto']}"],
            ['Sales: '],
            ['Cost Center' ,'Date','Reference','Customer','Sales Amount', 'VAT Amount', 'Sales with VAT', 'Discount', 'Net Sales', ' Salesman/Cashier', 'VAT Type']
        ];

        
        $sales_fields = (array_map(function($data){ 
            return array_values(array_map(function($field){
                return is_numeric($field)? number_format($field, 2, '.', ','): $field;
            },$data));
        }, $sales));

        $csvarray = array_merge($csvarray, $sales_fields);
       
        array_push($csvarray, ['Sales Return: ']);
        array_push($csvarray, ['Cost Center', 'Date', 'Sales Reference', 'Sales Return Reference', 'Customer Name', ' Amount', 'Salesman']);
        $return_fields = (array_map(function($data){ 
            return array_values(array_map(function($field){
                return is_numeric($field)? number_format($field, 2, '.', ','): $field;
            },$data));
        }, $return));
        $csvarray = array_merge($csvarray, $return_fields);
        setLogs(
            array(
                'actionLogDescription' => $this->USERFULLNAME . ' Exported the generated Sales Summary Report (Excel)'
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 24
                ,'time'                => date('H:i:s A')
            )
        );
        writeCsvFile(
            array(
                'csvarray' 	 => $csvarray
                ,'title' 	 => $params['title']
                ,'directory' => 'inventory'
            )
        );
    }

    function download($title){
		force_download(
			array(
				'title' => $title
				,'directory' => 'inventory'
			)
		);
	}	

    private function pdfColFormat($header, $dataIndex, $width = false, $type=false){
        $return = [
            'header' => $header,
            'data_index' => $dataIndex
        ];
        if($width != false) $return['width'] = $width;
        if($type != false) $return['type'] = $type;
        return $return;
        
    }

}