<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Mark Reynor D. Magriña
 * Module: Item Settings
 * Date: Dec 05, 2019
 * Finished: 
 * Description: 
 * DB Tables: 
 * For Password Hashing, please use password_hash( https://www.php.net/manual/en/function.password-hash.php )
 * */
class Item extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'inventory/Item_model' );
    }
		
	public function getAffiliate(){
        $params = getData();
		$view   = $this->model->getAllAffiliate($params);
        die( json_encode( array( 'success' => true ,'view' => $view ) ) );
    }
	public function getItemClassification(){
        $params = getData();
		$view   = $this->model->getItemClassification($params);
        die( json_encode( array( 'success' => true ,'view' => $view ) ) );
    }
	public function getItemUnit(){
        $params = getData();
		$view   = $this->model->getItemUnit($params);
        die( json_encode( array( 'success' => true ,'view' => $view ) ) );
    }
	function getCOADetails(){
		$data = getData();
		$record = $this->model->getCOADetails( $data );
		die( json_encode( array( 'success' => true ,'view' => $record )));
	}
	function getItemListDetails(){
		$data = getData();
		$record = $this->model->getItemListDetails( $data );
		die( json_encode( array( 'success'=> true, 'total'=> $record['count'], 'view'=> $record['view'] ) ) );
	}
	function getSearchedItems(){
		$data = getData();
		$record = $this->model->getSearchedItems( $data );
		die( json_encode( array( 'success' => true ,'view' => $record )));
	}
	public function retrieveData(){
		$rawData = getData();
		$record = $this->model->retrieveData($rawData['idItem']); 		
		die( json_encode( array( 'success'=>true, 'view'=>$record ) ) );
	}
	public function getItemPriceHistoryDetails(){
		$rawData = getData();
		$record = $this->model->getItemPriceHistoryDetails($rawData);
		die( json_encode( array( 'success'=>true, 'view'=> $record ) ) );
	}
	public function saveItemForm(){
		$rawData = getData();
				
		// print_r($rawData);
		// die();
				
		if( $rawData['onEdit'] == 0 ) {
			$checkDuplicate = $this->model->checkDupliate($rawData['barcode']);		
			if( $checkDuplicate > 0 ) die( json_encode( array('success'=> true, 'match'=>1)));
		}else{
			$checkExist = $this->model->checkExist($rawData['idItem']);		
			if( $checkExist == 0 ) die( json_encode( array('success'=> true, 'match'=>2)));
		}
		
		$this->db->trans_begin();// firstline	
		$idItem=$this->model->saveItemForm($rawData);			
		if( $rawData['onEdit'] == 0 ) { 
			$idItem = $idItem;
			/* save the first price */
			$rawData['idItem'] = $idItem;
			$this->model->saveFirstPrice($rawData);
		}
		else{ $idItem = (int)$rawData['idItem']; }
		$idItemField = array( 'idItem'=> $idItem );
		
		
		/* Prepare affiliate list for batch saving */
		$affiliateList= json_decode($rawData['affiliateList'], true);
		for ( $i=0; $i < count($affiliateList); $i++ ) {
			unset($affiliateList[$i]['affiliateName']);
			unset($affiliateList[$i]['chk']);
			$affiliateList[$i] +=  $idItemField;
		}
		$this->model->saveAffiliateList($affiliateList,$idItem);	
		// echo(', agi ko save affiliate');
		
		/* Set Logs */
		if($rawData['onEdit'] == 0){ $actioLog = 'added a new Item, '.$rawData['itemName']; }
		else{ $actioLog = 'edited an item details, '.$rawData['itemName']; }	
		setLogs( array(
			'actionLogDescription' => $actioLog
			,'idEu' => $this->USERID
			,'idAffiliate' => $this->AFFILIATEID
			,'moduleID' => 16
			,'time' => date("H:i:s A")
		));
		
		if( $this->db->trans_status() === FALSE ){
			$this->db->trans_rollback(); // rollback changes
		}
		else{
			$this->db->trans_commit(); // submit changes
		}
		die( json_encode( array( 'success'=>$this->db->trans_status(), 'match'=>0 ) ) );
	}
	public function saveItemPriceHistory(){
		$rawData = getData();
		$itemPriceHistoryList= json_decode($rawData['itemPriceHistoryList'], true);
		$idItem = array( 'idItem'=> $rawData['idItem'] );
		for ( $i=0; $i < count($itemPriceHistoryList); $i++ ) {
			$itemPriceHistoryList[$i]['idItem'] =  $rawData['idItem'];
		}
		$this->model->saveItemPriceHistory($itemPriceHistoryList,$rawData['idItem']);	
		
		$this->db->trans_begin();// firstline	
			$this->model->saveItemPriceHistory($itemPriceHistoryList,$rawData['idItem']);
		if( $this->db->trans_status() === FALSE ){
			$this->db->trans_rollback(); // rollback changes
		}
		else{
			$this->db->trans_commit(); // submit changes
		}
		die( json_encode( array( 'success'=>$this->db->trans_status(), 'match'=>0 ) ) );
	}
	public function deleteItemRecord(){
		$rawData = getData();
		$match = 1;
		$checkTransactions = $this->model->checkUsage($rawData['idItem']);
		if( $checkTransactions > 0 ){ $match = 0; }
		else{
			$this->model->deleteItemRecord( $rawData['idItem'] );
			$match = 1;
		}
		$messageLog = 'deleted an item '.$rawData['itemName'];
		setLogs( array(
			'actionLogDescription' => $messageLog
			,'idEu' => $this->USERID
			,'idAffiliate' => $this->AFFILIATEID
			,'moduleID' => 16
			,'time' => date("H:i:s A")
		));
		die( json_encode( array( 'success'=>true, 'match'=>$match ) ) );
	}
	
	function generateItemSettingPDF(){
		$rawData = getData();
		$record = $this->model->getItemListDetails($rawData);
		
		$header = array(
			array(
				'header'	=> 'Code'
				,'dataIndex'=>'barcode'
				,'width'	=> '10%'
			)
			,array(
				'header'	=> 'Item Name'
				,'dataIndex'=> 'itemName'
				,'width'	=> '43%'
			)
			,array(
				'header'	=> 'Classification'
				,'dataIndex'=> 'className'
				,'width'	=> '10%'
			)
			,array(
				'header'	=> 'Price'
				,'dataIndex'=> 'itemPrice'
				,'width'	=> '10%'
				,'type'		=> 'numbercolumn'
				,'format'	=> '0,000.00'
			)
			,array(
				'header'	=> 'Effectivity Date'
				,'dataIndex'=> 'effectivityDate'
				,'width'	=> '10%'
			)
			,array(
				'header'	=> 'Unit'
				,'dataIndex'=> 'unitName'
				,'width'	=> '10%'
			)
			,array(
				'header'	=> 'Reorder level'
				,'dataIndex'=> 'reorderLevel'
				,'width'	=> '10%'
				,'type'		=> 'numbercolumn'
			)
		);
		
		$array = array(
			'file_name'		=> $rawData['pageTitle']
			,'folder_name'	=> 'inventory'
			,'records'		=> $record['view']
			,'header'		=> $header
			,'orientation'	=> 'L'
		);
		generateTcpdf($array);
	}
	function generateItemSettingExcel(){
		$rawData = getData();
		$sum = 0;
		$record = $this->model->getItemListDetails($rawData);
		$csvarray[] = array( 'title' => $rawData['pageTitle'].'');
		$csvarray[] = array( 'space' => '' );
		$csvarray[] = array( 'space' => '' );
		
		$csvarray[] = array(
			'col1' 	=> 'Code'
			,'col2'	=> 'Item Name'
			,'col3'	=> 'Classification'
			,'col4'	=> 'Price'
			,'col5'	=> 'Effectivity Date'
			,'col6'	=> 'Unit'
			,'col7'	=> 'Reorder level'
		);
		
		foreach( $record['view'] as $value ){
			$csvarray[] = array(
				'col1' 	=> $value['barcode']
				,'col2'	=> $value['itemName']
				,'col3'	=> $value['className']
				,'col4'	=> $value['itemPrice']
				,'col5'	=> $value['effectivityDate']
				,'col6'	=> $value['unitName']
				,'col7'	=> $value['reorderLevel']
			);
		}
		
		$rawData['description'] = ''.$rawData['pageTitle'].": ".$this->USERNAME.' printed a Excel report';
		$rawData['iduser'] = $this->USERID;
		$rawData['usertype'] = $this->USERTYPEID;
		$rawData['printExcel'] = true;
		$rawData['ident'] = null;
		
		writeCsvFile(
			array(
				'csvarray'		=> $csvarray
				,'title'		=> $rawData['pageTitle'].''
				,'directory'	=> 'inventory'
			)
		);
		
	}
	function download($title){
		
		echo 'abot dre kai';
		
		force_download(
			array(
				'title'		=> $title
				,'directory'=> 'inventory'
			)
		);
	}

}