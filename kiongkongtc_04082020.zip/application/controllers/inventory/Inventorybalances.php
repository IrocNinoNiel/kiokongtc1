<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Inventorybalances extends CI_Controller
{
   public function __Construct()
   {
      parent::__Construct();
      setHeader( 'inventory/Inventorybalances_model' );
   }

   public function getItemClass()
   {
      $params = getData();
      $view   = $this->model->getItemClassifications();

      array_unshift( $view, array(
         'id' => 0
         ,'name' => 'All'
      ));

      die(
         json_encode(
            array(
               'success' => true 
               ,'view' => $view
            )
         )
      );
   }

   public function getItems()
   {
      $params = getData();
      $view   = $this->model->getItems( $params );

      array_unshift( $view, array(
         'id' => 0
         ,'name' => 'All'
      ));
      
      die(
         json_encode(
            array(
               'success' => true 
               ,'view' => $view
            )
         )
      );
   }

   public function getInventoryBalances()
   {
      $params = getData();
      $view = $this->model->getInventoryBalances( $params );
      
      setLogs(
         array(
            'actionLogDescription' => 'Generates Inventory Balances.'
            ,'idEu'                => $this->USERID
            ,'moduleID'            => 61
            ,'time'                => date('H:i:s A')
         )
      );

      die(
         json_encode(
            array(
               'success' => true
               ,'view' => $view
               ,'params' => $params
            )
         )
      );
   }
   
   function printPDF(){
      $params = getData();
      $data = $this->model->getInventoryBalances( $params );

      $col = array(
         array(   
            'header'        => 'Affiliate'
            ,'dataIndex'    => 'affiliateName'
            ,'width'        => '20%'
         )
         ,array(  
            'header'        => 'Item Name'
            ,'dataIndex'    => 'itemName'
            ,'width'        => '15%'
         )
         ,array(  
            'header'        => 'Classification'
            ,'dataIndex'    => 'className'
            ,'width'        => '15%'
         )
         ,array(  
            'header'        => 'Unit'
            ,'dataIndex'    => 'unitCode'
            ,'width'        => '10%'
         )
         ,array(  
            'header'        => 'Cost'
            ,'dataIndex'    => 'cost'
            ,'width'        => '15%'
            ,'type'         => 'numbercolumn'
            ,'format'       => '0,000.00'
         )
         ,array(  
            'header'        => 'Reorder Point'
            ,'dataIndex'    => 'reorderLevel'
            ,'width'        => '10%'
            ,'type'         => 'numbercolumn'
            ,'format'       => '0,000'
         )
         ,array(  
            'header'        => 'Balance'
            ,'dataIndex'    => 'balance'
            ,'width'        => '15%'
            ,'type'         => 'numbercolumn'
            ,'format'       => '0,000.00'
         )
      );
      
      $header_fields = array(
         array(
            array(
               'label'     => 'Affiliate'
               ,'value'    => $params['pdf_idAffiliate']
            )
            ,array(
               'label'     => 'Classification'
               ,'value'    => $params['pdf_idItemClass']
            )
            ,array(
               'label'     => 'Item'
               ,'value'    => $params['pdf_idItem']
            )
            ,array(
               'label'     => 'View Records As Of'
               ,'value'    => $params['pdf_datefrom'] . ' ' .  date( 'h:i A', strtotime($params['pdf_timefrom']) )
            )
         )
      );

      setLogs(
         array(
            'actionLogDescription' => 'Exported the generated Inventory Balances Report (PDF).'
            ,'idEu'                => $this->USERID
            ,'moduleID'            => 61
            ,'time'                => date('H:i:s A')
         )
      );

      generateTcpdf(
          array(
              'file_name' => $params['title']
              ,'folder_name' => 'inventory'
              ,'records' => $data
              ,'header' => $col
              ,'orientation' => 'P'
              ,'header_fields' => $header_fields
          )
      );
   }

   function printExcel(){
      $params = getData();
      $data = $this->model->getInventoryBalances( $params );

      $csvarray = array();

      $csvarray[] = array( 'title' => $params['title'] );
      $csvarray[] = array( 'space' => '' );

      $csvarray[] = array( 'Affiliate', $params['pdf_idAffiliate'] );
      $csvarray[] = array( 'Classification', $params['pdf_idItemClass'] );
      $csvarray[] = array( 'Item', $params['pdf_idItem'] );
      $csvarray[] = array( 'View Records as of', $params['pdf_datefrom'] . ' ' . date( 'h:i A', strtotime( $params['pdf_timefrom'] ) ) );
      $csvarray[] = array( 'space' => '' );

      $csvarray[] = array(
         'Affiliate'
         ,'Item Name'
         ,'Classification'
         ,'Unit'
         ,'Cost'
         ,'Reorder Point'
         ,'Balance'
      );

      foreach( $data as $d ){
         $csvarray[] = array(
            $d['affiliateName']
            ,$d['itemName']
            ,$d['className']
            ,$d['unitCode']
            ,number_format( $d['cost'], 2 )
            ,number_format( $d['reorderLevel'] )
            ,number_format( $d['balance'] )
         );
      }

      setLogs(
         array(
            'actionLogDescription' => 'Exported the generated Inventory Balances Report (EXCEL).'
            ,'idEu'                => $this->USERID
            ,'moduleID'            => 61
            ,'time'                => date('H:i:s A')
         )
      );

      writeCsvFile(
         array(
            'csvarray' 	 => $csvarray
            ,'title' 	 => $params['title']
            ,'directory' => 'inventory'
         )
      );
   }

   function download( $title, $folder ){
      force_download(
         array(
            'title'      => $title
            ,'directory' => $folder
         )
      );
   }
}
