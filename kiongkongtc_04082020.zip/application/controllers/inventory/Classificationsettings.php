<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Hazel Alegbeleye
 * Module: Classification Settings
 * Date: December 4, 2019
 * Finished: December 4, 2019
 * Description: This module allows authorized users to set (add, edit and delete) an item classification. 
 * DB Tables: itemclassification, item
 * */
class Classificationsettings extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'inventory/Classificationsettings_model' );
    }

    function getClassCode() {
        $params = getData();
        $view = $this->model->getClassCode( $params );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    function getItemClassifications() {
        $params = getData();
        $view = $this->model->getItemClassifications( $params );


        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    function retrieveData() {
        $params = getData();
        $view = $this->model->retrieveData( $params );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    function saveClassification() {
        $params = getData();
        $view = $this->model->saveClassification( $params );

        $msg = ( !$params['onEdit'] ) ? ' edited the classification details.' : ' added a new classification.';

        setLogs(
            array(
                'actionLogDescription' => $this->USERNAME . $msg
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 14
                ,'time'                => date("H:i:s A")
            )
        );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'view' => $view
                )
            )
        );
    }

    function deleteClassification() {
        $params = getData();
        $match = $this->model->deleteClassification( $params );

        setLogs(
            array(
                'actionLogDescription' => $this->USERNAME . ' deleted a classification'
                ,'idEu'                => $this->USERID
                ,'moduleID'            => 14
                ,'time'                => date("H:i:s A")
            )
        );

        die(
            json_encode(
                array(
                    'success' => true
                    ,'match' => $match
                )
            )
        );
    }

    public function generatePDF(){
        $data = getData();
        $list = $this->model->getItemClassifications( $data );

        $header = array(
            array(
                'header'=>'Classification Code'
                ,'dataIndex'=>'classCode'
                ,'width'=>'40%'	
            ),
            array(
                'header'=>'Classification Name'
                ,'dataIndex'=>'className'
                ,'width'=>'60%'
            ),
        );

        $array = array(
            'file_name'	=> $data['pageTitle']
            ,'folder_name' => 'settings'
            ,'records' =>  $list
            ,'header' => $header
       );
       
       $data['ident'] = null;
       generateTcpdf($array);
    }
}