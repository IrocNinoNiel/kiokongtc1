<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Mark Reynor D. Magriña
 * Module: Stocktransfer Module
 * Date: Feb 04, 2020
 * Finished: 
 * Description: 
 * DB Tables: 
 * For Password Hashing, please use password_hash( https://www.php.net/manual/en/function.password-hash.php )
 * */
class Stocktransfer extends CI_Controller {

	public function __construct(){
        parent::__construct();
        setHeader( 'inventory/Stocktransfer_model' );
    }
	
	function getGridListForPayments(){
		$rawData = getData();
		
		// echo $rawData['idInvoice'];
		// die();
		
		$record = $this->model->getGridListForPayments( $rawData ) ;
		die( json_encode( array( 'success'=>true, 'view'=> $record ) ) );
	}
	
	
	function getItems() {
        $rawData = getData();
		
		// print_r($rawData);
		// die();
		
        $view = $this->model->getItems( $rawData );
		
		// print_r($view);
		// die();
		
        die( json_encode( array( 'success' => true ,'view' => $view ) ) );
    }
	function getStockTransferDetails(){
		$rawData = getData();
		$record = $this->model->getStockTransferDetails($rawData);
		die( json_encode( array( 'success'=>true, 'view'=>$record ) ) );
	}
	
	function saveStockTransferForm(){		
		$rawData = getData();
		$rawData['pType'] = 3;
		print_r($rawData);
		die();
		
		$this->db->trans_begin();// firstline		
		$stInvoiceID = $this->model->saveInvoiceStockTransfer($rawData);
		
		/* Set the invoice id according to transaction state. */
		if( (int)$rawData['onEdit'] == 0 ) { $stInvoiceID = $stInvoiceID;}
		else{ $stInvoiceID = (int)$rawData['idInvoice']; }
		
		/* Prepare stock transfer details for batch saving */
		$gridItemList = json_decode( $rawData['gridItemList'] , true );
		for( $i=0; $i < count($gridItemList); $i++ ){
			$gridItemList[$i]['idInvoice'] = $stInvoiceID;
		}
		$this->model->saveGridItemList($gridItemList,$stInvoiceID);
		
		/* Set the journal details for batch saving */
		$journalDetails = json_decode( $rawData['journalDetails'],true );
		for( $i=0; $i < count($journalDetails); $i++ ){
			$journalDetails[$i]['idInvoice'] = $stInvoiceID;
		}
		$this->model->saveJournalDetails($journalDetails,$stInvoiceID);		

/* 		
		Save		<username> transferred stock/s to <location>
		Edit		<username> edited a transaction
		Delete		<username> deleted a transaction
		Cancel		<username> cancelled a transaction
		Confirm		<username> confirmed a stock transfer
 */
		
		/* Set Logs */
		if($rawData['onEdit'] == 0){ $actioLog = $this->USERNAME.' transferred stocks to '. $rawData['receiverAffiliate']; }
		else{ $actioLog = $this->USERNAME.' edited a transaction'; }
		setLogs( array(
			'actionLogDescription' => $actioLog
			,'idEu' => $this->USERID
			,'moduleID' => 43
			,'time' => date("H:i:s A")
		));
		
		if( $this->db->trans_status() === FALSE ){
			$this->db->trans_rollback(); // rollback changes
		}
		else{
			$this->db->trans_commit(); // submit changes
		}
		die( json_encode( array( 'success'=>$this->db->trans_status(), 'match'=>0 ) ) );
	}
	
	function retrieveData(){
		$rawData = getData();
		$record = $this->model->retrieveData($rawData);
		die( json_encode( array( 'success'=>true, 'view'=>$record ) ) );
	}
	function getItemListDetails(){
		$rawData = getData();
		$record = $this->model->getItemListDetails($rawData);
		die( json_encode( array( 'success'=>true, 'view'=>$record ) ) );
	}
	function deleteStockTransferRecord(){
		$rawData = getData();
		$match = 0;
		/* Create a filtering process to check if the Items received were still intact if not, prohibit delete */
		
		/* Add code block here to delete the ST releasing, ST Receiving if not used by releasing module */
		$this->model->deleteStockTransferRecord($rawData['idInvoice']);
		$this->model->deleteStockTransferDetails($rawData['idInvoice']);
		
		setLogs( array(
			'actionLogDescription' => $this->USERNAME.' deleted a transaction'
			,'idEu' => $this->USERID
			,'moduleID' => 43
			,'time' => date("H:i:s A")
		));
		die( json_encode( array( 'success'=>true, 'match'=> $match ) ) );
	}

}