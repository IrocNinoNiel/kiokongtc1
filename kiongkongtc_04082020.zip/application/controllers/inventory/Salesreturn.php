<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Salesreturn extends CI_Controller {

    public function __construct(){
        parent::__construct();
        setHeader( 'inventory/Salesreturn_model' );
        $this->load->model('standards/Standards2_model', 'standard2');
    }

    public function getCustomerItem(){
        $params = getData();
        if(!isset($params['idInvoice'])) die(json_encode(['status'=>true, 'view'=>[]]));
        $view  = $this->model->getCustomerItem($params);
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
        );
    }
    public function getCustomerInvoice(){
        $params = getData();
        $view  = $this->model->getCustomerInvoice($params);
        if(isset($params['with_id'])){
			$add = $this->model->currentInvoice($params['with_id']);
			$view = array_merge($view, $add);
		}
        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $view
				)
			)
        );
    }

    public function save(){
        $this->db->trans_start();

        $params = getData();

        if ( $this->model->isClosedJE( $params ) > 0 ) { 
            die(
                json_encode(
                    array(
                        'success' => true
                        ,'match'  => 4
                    )
                )
            );
        }

        $params['items'] = json_decode($params['items'], true);
        $params['journals'] = json_decode($params['journals'], true);
        $invoice = [
            "idAffiliate" => $params["idAffiliate"],
            "idReference" => $params["idReference"],
            "idCostCenter" => $params["idCostCenter"],
            "referenceNum" => $params["referenceNum"],
            "idReferenceSeries" => $params["idReferenceSeries"],
            "cancelTag" => $params["cancelTag"],
            "idModule" => SALES_RETURN,
            "date" => $params["tdate"]." ".$params["ttime"],
            "pType" => 1,
            "pCode" => $params["pCode"],
            "amount" => $params["totalamt"],
            "remarks" => $params["remark"],
            "dateModified" => $params["dateModified"],
            "hasJournal" => (count($params["journals"]) > 0),
            "fident" => $params['invoices'],
            "preparedBy" => $this->session->userdata('USERID'),
            'status' => APPROVED
        ];
        if($params['idInvoice'] != NULL){
			$params['action']   = 'edited a transaction';
            $id = $params['idInvoice'];
            $this->model->returnReceived(['idInvoice'=>$id]);
            $this->model->deleteAssociateChild(['id'=>$id]);
            $this->model->update('invoices', $invoice, ['idInvoice'=>$id]);

           
        }else{
			$params['action']   = 'added a new Sales Return transaction';
            $id = $this->model->insert($invoice, 'invoices'); 
        }
        $invoice['idInvoice'] = $id;
		$this->model->insert($invoice, 'invoiceshistory');
        $data = $this->format($params, $id);
        if(count($data['items']) > 0){
            $this->model->insertBulk($data['items'], 'receiving');
        }
        if(count($data['journals']) > 0){
            $this->model->insertBulk($data['journals'], 'posting');
        }
        if(count($data['items_update']) > 0){
            $this->model->updateBulk($data['items_update'], 'releasing', 'idReleasing');
        }

        if ($this->db->trans_status() === FALSE) {
			$this->db->trans_rollback();
			die(
				json_encode(
					array(
						'success' => false
					)
				)
			);
		} 
		else {
			$this->db->trans_commit();
            $this->setLogs( $params );
			die(
				json_encode(
					array(
                        'success' => true
					)
				)
			);
		}
    }

    public function delete() {
        $params = getData();
        $match = $this->model->checkMutation('receiving', ['receiving.idInvoice'=>$params['id']])[0]['state'];

        //cancelTag
        if ( (int)$this->model->cancelTag( $params['id'] ) == 1 ) {
            $match = 2;
        }
        
        if($match == IS_MUTABLE){
			$this->model->update('invoices', ['archived' => POSITIVE], ['idInvoice' => $params['id']]);
            $this->model->returnReceived(['idInvoice'=>$params['id']]);
            
            $params['action']   = 'deleted a transaction';
            $this->setLogs( $params );
        }

        die(
			json_encode(
				array(
                    'success' => true
                    ,'match' => (int) $match
				)
			)
        );
	}

    public function getInvoices(){
        $params = getData();
        $data = $this->model->viewAll($params);

        die(
			json_encode(
				array(
					'success' => true
                    ,'view' => $data['view']
					,'total' => $data['count']
				)
			)
        );
    }

    public function updateTransaction(){
        $params = getData();
        
        $this->model->update('invoices', ['status'=>$params['status'], 'idInvoice' => $params['idInvoice'], 'notedby' => $this->session->userdata('USERID')], [ 'idInvoice' => $params['idInvoice']]);
        if($params['status'] == CANCELLED){
			$this->model->returnReceived(['idInvoice'=>$params['idInvoice']]);
        }
        die(
			json_encode(
				array(
					'success' => true
				)
			)
        );
    }

    private function format($data, $invoice){
        $items = [];
        $items_update = [];
        $journals = [];

        $data['idLocation'] =  $this->session->userdata('LOCATIONID');
        $data['receivedBy'] =  $this->session->userdata('USERID');
        foreach($data['items'] as $key => $item){
            if((int)$item['qty'] == 0) continue;
            array_push($items, [
                'idItem' => $item['id'],
                'qty' =>  $item['qty'],
                'qtyLeft' =>  $item['qty'],
                'cost' => $item['cost'],
                'price' => $item['price'],
                'idInvoice' => $invoice,
                'fident' => $item['releasedID']
            ]);
            
            array_push($items_update,[
                'idReleasing' => $item['releasedID'],
                'qtyLeft' =>  (int) $item['remaining'] -  (int)$item['qty']
            ]);
        }

        foreach($data['journals'] as $key => $journal){
            array_push($journals, [
                'idInvoice' => $invoice,
                'explanation' =>  $journal['explanation'],
                'idCoa' =>  $journal['idCoa'],
                'idCostCenter' =>  $journal['idCostCenter'],
                'debit' =>  $journal['debit'],
                'credit' =>  $journal['credit'],
                'idSo' => 0
            ]);
        }

        return['items' => $items, 'journals' => $journals, 'items_update' => $items_update];
    }

    public function retrieve(){
        $params = getData();
        $view = $this->model->retrieveAll($params);
        $items = $this->model->retrieveItems($params);
        $match = $this->model->checkMutation('receiving', ['receiving.idInvoice'=>$params['id']])[0]['state'];

        //cancelTag
        if ( (int)$this->model->cancelTag( $params['id'] ) == 1 ) {
            $match = 2;
        }
        
        die(
			json_encode(
				array(
                    'success' => true
                    ,'view' => $view
                    ,'match' => (int) $match
					,'released' => $items
				)
			)
        );
    }

    public function getSearchRef(){
        $params = getData();
        $view   = $this->model->getSearchRef( $params );
        array_unshift(
            $view
            ,array(
                'id'     => 0
                ,'name'    => 'All'
            )
        );
        die(
            json_encode(
                array(
                    'success'   => true
                    ,'view'     => $view
                )
            )
        );
    }

    private function setLogs( $params ){
		$header = 'Sales Return : '.$this->USERFULLNAME;
		$action = '';
		
		if( isset( $params['deleting'] ) ){
			$action = 'deleted a transaction';
		}
		else{
			if( isset( $params['action'] ) )
				$action = $params['action'];
			else
				$action = ( $params['onEdit'] == 1  ? 'modified' : 'added new' );
		}
		
		setLogs(
            array(
                'actionLogDescription'  => $header . ' ' . $action
                ,'idReference'			=> $params['idReference']
                ,'referenceNum'			=> $params['referenceNum']
                ,'idModule'				=> $params['idmodule']
            )
        );
    }

}