<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Mark Reynor D. Magri�a
 * Module: Disbursements Module
 * Date: Feb 10, 2020
 * Finished: 
 * Description: 
 * DB Tables: 
 * */
class Disbursements_model extends CI_Model {
	
	function getGridListForPayments($rawData){
		
		/* Edited or saved cash receipts statments here */
		if( (int)$rawData['idInvoice'] != 0 || !$rawData['idInvoice'] ){
			// echo 'sulod ko edited record';
			
			$this->db->select("
				CONCAT(salesReference.code, ' - ',salesInvoices.referenceNum) as reference	
				,salesInvoices.idInvoice as salesIDInvoice
				,DATE_FORMAT(salesInvoices.date,'%Y-%m-%d') as date
				,(IF(salesInvoices.balLeft > 0,salesInvoices.balLeft,0) + receipts.amount) as receivables 
				,receipts.amount as collections
				,(( IF(salesInvoices.balLeft > 0,salesInvoices.balLeft,0) + receipts.amount) - receipts.amount ) as balance
			");
			$this->db->where('invoices.idInvoice', $rawData['idInvoice'] );
			
			$this->db->join('receipts','receipts.idInvoice = invoices.idInvoice','left outer');		
			$this->db->join('invoices as salesInvoices','salesInvoices.idInvoice = receipts.fident','left outer');
			$this->db->join('reference as salesReference','salesReference.idReference = salesInvoices.idReference','left outer');
		}
		else{ /* New sales record fetch statements here */
			// echo 'sulod ko new record';
			
			$this->db->select("
				CONCAT(reference.code, ' - ',invoices.referenceNum) as reference
				,invoices.idInvoice as salesIDInvoice
				,DATE_FORMAT(invoices.date,'%Y-%m-%d') as date
				,invoices.balLeft as receivables 
				,0 as collections
				,invoices.balLeft as balance
			");
			$this->db->where('invoices.pCode', $rawData['idCustomer'] );
			$this->db->where('invoices.date <=', $rawData['tDate']);
			$this->db->where('invoices.status',2);
		}
		$this->db->from('invoices');
		$this->db->where('invoices.pType',1);
		$this->db->join('reference','reference.idReference = invoices.idReference','left outer');
		return $this->db->get()->result_array();
	}
	
	function getPayablesList( $rawData ){
		/* Edited or saved cash receipts statments here */
		// if( (int)$rawData['idInvoice'] != 0 || !$rawData['idInvoice'] ){
			
		// getType($rawData['idInvoice']);
		
		
		// if ( (int)$rawData['idInvoice'] != 0 || !$rawData['idInvoice'] ){
			// echo 'dre lagi kay';
		// }else{
			// echo 'uu dre pod';
		// }
		
		// die();
			
		// if( !$rawData['idInvoice'] && (int)$rawData['idInvoice'] != 0 ){

		if( isset( $rawData['idInvoice'] ) && (int)$rawData['idInvoice'] != 0 ){
			// echo 'sulod ko edited record';
			
			$this->db->select("
				CONCAT( sourceReference.code, '-',sourceInvoice.referenceNum) as reference
				,sourceInvoice.idInvoice as sourceIDInvoice
				,DATE_FORMAT( sourceInvoice.date, '%Y-%m-%d' ) as date
				,(if( sourceInvoice.balLeft > 0, sourceInvoice.balLeft,0) + receipts.amount ) as payables
				,receipts.amount as paid
				,(( if( sourceInvoice.balLeft > 0, sourceInvoice.balLeft, 0 ) + receipts.amount ) - receipts.amount ) as balance
			");
			$this->db->where('invoices.idInvoice', (int)$rawData['idInvoice']);
			$this->db->join('receipts','receipts.idInvoice = invoices.idInvoice','left outer');
			$this->db->join('invoices as sourceInvoice','sourceInvoice.idInvoice = receipts.fident','left outer');
			$this->db->join('reference as sourceReference','sourceReference.idReference = sourceInvoice.idReference','left outer');
		}else{ /* New sales record fetch statements here */
			// echo 'sulod ko new record';
			
			$this->db->select("
				CONCAT(reference.code,'-',invoices.referenceNum) as reference, 
				,invoices.idInvoice as receivingIDInvoice
				,invoices.idModule as fIDModule
				,DATE_FORMAT(invoices.date, '%Y-%m-%d') as date
				,invoices.balLeft as payables
				,0 as paid
				,invoices.balLeft as balance
			");
			
			$this->db->where( 'invoices.pCode' , $rawData['idSupplier'] );
			$this->db->where( 'invoices.date <= "' . $rawData['tDate'] . '"');

			if ( isset( $rawData['otherTag'] ) && $rawData['otherTag'] != "false" ) {
				$this->db->WHERE_IN( 'invoices.IdModule', [ 25, 57 ] );
			} else {
				$this->db->WHERE( 'invoices.IdModule', 25 );
			}	

			$this->db->WHERE_NOT_IN( 'invoices.cancelTag' , 1 );
			$this->db->WHERE_NOT_IN( 'invoices.archived' , 1 );
			$this->db->WHERE( 'invoices.status' , 2 );
			$this->db->WHERE( 'invoices.pType' , 2 );
			$this->db->GROUP_BY( ' invoices.idInvoice '); 
			$this->db->ORDER_BY( 'invoices.date' , 'DESC' ); 
		}

		$this->db->join('reference','reference.idReference = invoices.idReference','left outer');
		return $this->db->get( 'invoices' )->result_array();
	}
	
	
	function getItems( $params ){
        if( isset( $params['idAffiliate']) ) {
            $qty = ( isset($params['qty']) ? $params['qty'] : 1 );
            $this->db->select(' item.idItem,itemName,itemclassification.className,barcode,unit.unitName, 
                                itemPrice as cost, ' . $qty . ' as qty, 
                                ( itemPrice * ' . $qty . ' ) as amount ');
            $this->db->where('idAffiliate', $params['idAffiliate']);
            $this->db->join('itemclassification', 'item.idItemClass = itemclassification.idItemClass', 'LEFT');
            $this->db->join('unit', 'item.idUnit = unit.idUnit', 'LEFT');
            $this->db->join('itemaffiliate', 'item.idItem = itemaffiliate.idItem', 'LEFT');
            return $this->db->get('item')->result_array();
        }
    }
	function getSupplier($rawData){
		$this->db->distinct();
		$this->db->select('supplier.idSupplier as id, supplier.name, creditLimit');
		$this->db->from('supplier');
		$this->db->order_by('name asc');
		$this->db->join('supplieraffiliate','supplieraffiliate.idSupplier = supplier.idSupplier','left outer');
		return $this->db->get()->result_array();
	}
	function getPayables($dsInvoiceID){
		$this->db->select('receipt.*,invoices.balLeft');
		$this->db->where('receipt.idInvoice', $dsInvoiceID);
		$this->db->from ('receipts as receipt');
		$this->db->join('invoices as invoices','invoices.idInvoice = receipt.fident','left outer');
		return $this->db->get()->result_array();
	}
	function getDisbursementDetails(){
		$this->db->select(
			" invoices.idInvoice, DATE_FORMAT(invoices.date,'%Y-%m-%d') as date
			, CONCAT(reference.code, '-', invoices.referenceNum) as referenceNum, invoices.amount
			, affiliate.affiliateName
			, costcenter.costCenterName
			, location.locationName
			, customer.name as customerName
			, employeePreparedBy.name as preparedByName
			, employeeNotedBy.name as notedByName
			, (CASE 
				WHEN invoices.status = 1 THEN 'Pending'
				WHEN invoices.status = 2 THEN 'Approved'
				ELSE 'Cancelled'
			END) as status"
		);
		$this->db->from( 'invoices' );
		$this->db->join( 'affiliate','affiliate.idAffiliate = invoices.idAffiliate','left outer' );
		$this->db->join( 'costcenter','costcenter.idCostCenter = invoices.idCostCenter','left outer' );
		$this->db->join( 'reference','reference.idReference = invoices.idReference','left outer' );
		$this->db->join( 'location','location.idLocation = invoices.idLocation','left outer' );
		$this->db->join( 'customer','customer.idCustomer = invoices.pCode','left outer' );
		$this->db->join( 'eu as euPreparedBy','euPreparedBy.idEu = invoices.preparedBy','left outer' );
		$this->db->join( 'employee as employeePreparedBy','employeePreparedBy.idEmployee = euPreparedBy.idEmployee','left outer' );
		$this->db->join( 'eu as euNotedBy','euNotedBy.idEu = invoices.notedby','left outer' );
		$this->db->join( 'employee as employeeNotedBy','employeeNotedBy.idEmployee = euNotedBy.idEmployee','left outer' );
		$this->db->where('invoices.idModule',45);
		$this->db->order_by('invoices.idInvoice','desc');
		$this->db->where_not_in('invoices.archived',1);
		
		// to be uncommented when using the new database
		
		return $this->db->get()->result_array();
	}
	function getBankDetails($rawData){
		$this->db->select('idBankAccount as idBank , bankAccount as bankName');
		$this->db->from('bankaccount');
		if( isset($rawData['query'] ) ) $this->db->like('bankAccount',$rawData['query'],'both');
		$this->db->order_by('bankAccount','asc');
		return $this->db->get()->result_array();
	}
	function getCollectionDetails( $rawData ){
		$this->db->select("
			idPostdated,idInvoice,paymentMethod,(IF(chequeNo > 0,chequeNo,'')) as chequeNo,(IFNULL(NULL, date)) as date,amount,bankaccount.bankAccount as bankName,postdated.idBankAccount
			,(CASE
				WHEN paymentMethod = 1 THEN 'Cash'
				ELSE 'Cheque'	
			END) as type
		");
		$this->db->from('postdated');
		$this->db->where('idInvoice',$rawData['idInvoice']);
		$this->db->join('bankaccount','bankaccount.idBankAccount = postdated.idBankAccount','left outer');
		return $this->db->get()->result_array();		
	}
	function getBalLeft($fident){
		$this->db->select('balLeft');
		$this->db->where('idInvoice',$fident);
		return $this->db->get('invoices')->row();
	}
	function updateBalLeft($fident, $newAmount){
		$this->db->set('balLeft', $newAmount);
		$this->db->where('idInvoice', $fident);
		$this->db->update('invoices');
	}
	function saveInvoiceDisbursements($rawData){
		$id = (int)$rawData['idInvoice'];
		unset($rawData['idInvoice']);
		if( (int)$rawData['onEdit'] == 0 ){
			$this->db->insert('invoices', unsetParams($rawData, 'invoices') );
			return $this->db->insert_id();
		}
		else{
			$this->db->where('idInvoice', $id);
			$this->db->update('invoices', unsetParams($rawData, 'invoices') );
		}
	}
	function saveDisbursementDetails($paidDetails,$dsInvoiceID){
		$this->db->insert_batch( 'receipts', unsetParamsBatch( $paidDetails, 'receipts' ) );
	}
	function savePaymentList($paymentList,$dsInvoiceID){
		$this->db->insert_batch( 'postdated', unsetParamsBatch( $paymentList, 'postdated' )  );
	}
	function saveJournalDetails( $journalDetails,$crInvoiceID ){
		$this->db->delete( 'posting', array( 'idInvoice' => $crInvoiceID ) );
		$this->db->insert_batch( 'posting', unsetParamsBatch( $journalDetails, 'posting' ) );
	}
	function retrieveData( $idInvoice ){
		$this->db->select('*');
		$this->db->from('invoices');
		$this->db->where('idInvoice', $idInvoice);
		return $this->db->get()->result_array();
	}
	function delReceiptsDetails($dsInvoiceID){
		$this->db->delete( 'receipts', array( 'idInvoice' => $dsInvoiceID ) );
	}
	function delPostdatedDetails($dsInvoiceID){
		$this->db->delete( 'postdated', array( 'idInvoice' => $dsInvoiceID ) );
	}
	
	function deleteDisbursement($idInvoice){
		$this->db->delete( 'invoices', array( 'idInvoice' => $idInvoice ) );
	}
	
	
}