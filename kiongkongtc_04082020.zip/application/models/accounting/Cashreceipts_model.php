<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Mark Reynor D. Magri�a
 * Module: Sales Module
 * Date: Dec 12, 2019
 * Finished: 
 * Description: 
 * DB Tables: 
 * */
class Cashreceipts_model extends CI_Model {

	function getGridListForPayments($rawData){
		
		/* 
			If receipts.amount > 0 it means, it's a new record not edited 
			ONE Select statements all combined here which is honestly cool but would lead to problems someday, promise!
			For the next generation of Devs or when you go back to this line of code then you found out you can't read them at all ^_^
		*/
		/* 
		$this->db->select("
			IF(receipts.amount > 0, CONCAT(salesReference.code, ' - ',salesSource.referenceNum), CONCAT(reference.code, ' - ',invoices.referenceNum) )  as reference,
			IF(receipts.amount > 0,salesReference.idInvoice,invoices.idInvoice) as salesIDInvoice
			,IF(receipts.amount > 0,DATE_FORMAT(salesSource.date,'%Y-%m-%d'),DATE_FORMAT(invoices.date,'%Y-%m-%d') ) as  date
			,( IF(receipts.amount > 0, (IF(salesSource.balLeft > 0,salesSource.balLeft,0) + IF(receipts.amount > 0,receipts.amount,0) ), invoices.balLeft) ) as receivables 
			,(CASE 
					WHEN receipts.amount = 0 THEN 0
					ELSE receipts.amount
				END) as collections
			,( IF(receipts.amount > 0, ((IF(salesSource.balLeft > 0,salesSource.balLeft,0) + receipts.amount) - receipts.amount), IF(salesSource.balLeft > 0,salesSource.balLeft,0)) ) )as balance
		", true);
		
		$this->db->where('receipts.idInvoice', $rawData['idInvoice'] );
		$this->db->join('invoices as salesSource','salesSource.idInvoice = receipts.fident','left outer');
		$this->db->join('reference as salesReference','salesReference.idReference = salesSource.idReference','');
		
		$this->db->join('reference','reference.idReference = invoices.idReference','left outer');
		$this->db->join('receipts','receipts.idInvoice = invoices.idInvoice','left outer');		
		*/
		
		
		
		/* Edited or saved cash receipts statments here */
		// if ( isset( $rawData['idInvoice'] ) ){
			if( isset( $rawData['idInvoice'] ) && (int)$rawData['idInvoice'] != 0 ){
				// echo 'sulod ko edited record';
				// print_r($rawData);
				
				$this->db->select("
					CONCAT(salesReference.code, ' - ',salesInvoices.referenceNum) as reference	
					,salesInvoices.idInvoice as salesIDInvoice
					,DATE_FORMAT(salesInvoices.date,'%Y-%m-%d') as date
					,(IF(salesInvoices.balLeft > 0,salesInvoices.balLeft,0) + receipts.amount) as receivables 
					,receipts.amount as collections
					,(( IF(salesInvoices.balLeft > 0,salesInvoices.balLeft,0) + receipts.amount) - receipts.amount ) as balance
				");
				$this->db->where('invoices.idInvoice', (int)$rawData['idInvoice'] );
				
				$this->db->join('receipts','receipts.idInvoice = invoices.idInvoice','left outer');		
				$this->db->join('invoices as salesInvoices','salesInvoices.idInvoice = receipts.fident','left outer');
				$this->db->join('reference as salesReference','salesReference.idReference = salesInvoices.idReference','left outer');
			}
			else{ /* New sales record fetch statements here */
				// echo 'sulod ko new record';
				
				$this->db->select("
					CONCAT(reference.code, ' - ',invoices.referenceNum) as reference
					,invoices.idInvoice as salesIDInvoice
					,invoices.idModule as fIDModule
					,DATE_FORMAT(invoices.date,'%Y-%m-%d') as date
					,invoices.balLeft as receivables 
					,0 as collections
					,invoices.balLeft as balance
				");

				if ( isset( $rawData['otherTag'] ) && $rawData['otherTag'] != false ) {
					$this->db->WHERE_IN('invoices.idModule', [ 18, 48, 58 ] ); //From Sales module, Accounting Adjustment, Voucher's Receivable
				} else {
					$this->db->WHERE('invoices.idModule', 18 ); //From Sales module
				}

				$this->db->where('invoices.pCode', (int)$rawData['idCustomer'] );
				$this->db->where('convert(invoices.date, date) <=', $rawData['tDate'] );
				$this->db->where('invoices.status',2);
				$this->db->where('invoices.pType',1);
			}
			$this->db->from('invoices');
			$this->db->join('reference','reference.idReference = invoices.idReference','left outer');
			return $this->db->get()->result_array();
		// }
	}
	
	function getCollectionDetails($rawData){
		$this->db->select("
			idPostdated,idInvoice,paymentMethod,(IF(chequeNo > 0,chequeNo,'')) as chequeNo,(IFNULL(NULL, date)) as date,amount,bank.bankName,idBankAccount
			,(CASE
				WHEN paymentMethod = 1 THEN 'Cash'
				ELSE 'Cheque'	
			END) as type
		");
		$this->db->from('postdated');
		$this->db->where('idInvoice',$rawData['idInvoice']);
		$this->db->join('bank','bank.idBank = postdated.idBankAccount','left outer');
		return $this->db->get()->result_array();		
	}
	
	/*edit here*/
	function getBankAccountDetails($rawData){
		$this->db->select('idBankAccount,bankAccount');
		$this->db->from('bankaccount');
		if( isset($rawData['query'] ) ) $this->db->like('bankAccount',$rawData['query'],'both');
		$this->db->order_by('bankAccount','asc');
		return $this->db->get()->result_array();
	}
	
	function checkExist($idInvoice){
		$this->db->select('idInvoice');
		$this->db->where('idInvoice',$idInvoice);
		$this->db->from('invoices');
		return $this->db->count_all_results();
	}
	function getReceipts($crInvoiceID){
		$this->db->select('receipt.*,invoices.balLeft');
		$this->db->where('receipt.idInvoice', $crInvoiceID);
		$this->db->from ('receipts as receipt');
		$this->db->join('invoices as invoices','invoices.idInvoice = receipt.fident','left outer');
		return $this->db->get()->result_array();
	}
	function viewAll($rawData){
		$this->db->select("
					invoices.idInvoice, DATE_FORMAT(invoices.date,'%Y-%m-%d') as date, CONCAT(reference.code, '-', invoices.referenceNum) as referenceNum, invoices.amount
					,invoices.idInvoice as id,concat(reference.code, '-', invoices.referenceNum) as name
					,affiliate.affiliateName
					,costcenter.costCenterName
					,location.locationName
					,customer.name as customerName
					,employeePreparedBy.name as preparedByName
					,employeeNotedBy.name as notedByName
					,(CASE 
						WHEN invoices.status = 1 THEN 'Pending'
						WHEN invoices.status = 2 THEN 'Approved'
						ELSE 'Cancelled'
					END) as status
		");
		$this->db->from( 'invoices' );
		$this->db->join( 'affiliate','affiliate.idAffiliate = invoices.idAffiliate','left outer' );
		$this->db->join( 'costcenter','costcenter.idCostCenter = invoices.idCostCenter','left outer' );
		$this->db->join( 'reference','reference.idReference = invoices.idReference','left outer' );
		$this->db->join( 'location','location.idLocation = invoices.idLocation','left outer' );
		$this->db->join( 'customer','customer.idCustomer = invoices.pCode','left outer' );
		$this->db->join( 'eu as euPreparedBy','euPreparedBy.idEu = invoices.preparedBy','left outer' );
		$this->db->join( 'employee as employeePreparedBy','employeePreparedBy.idEmployee = euPreparedBy.idEmployee','left outer' );
		$this->db->join( 'eu as euNotedBy','euNotedBy.idEu = invoices.notedby','left outer' );
		$this->db->join( 'employee as employeeNotedBy','employeeNotedBy.idEmployee = euNotedBy.idEmployee','left outer' );
		$this->db->where('invoices.idModule',28);
		
		if( isset( $rawData['filterValue'] ) ) { 
			// echo 'Uli nami';
			$this->db->where( 'invoices.idInvoice', $rawData['filterValue']); 
		}
		
		// $this->db->order_by('invoices.idInvoice','desc');
		// $this->db->order_by('invoices.date','desc');
		$this->db->where_not_in('invoices.archived',1);
		
		if( isset( $params['query'] ) ) $this->db->like("concat(reference.code, '-', invoices.referenceNum)", $params['query'], 'after');
		
		// to be uncommented when using the new database
		// return $this->db->get()->result_array();
		
		$rawData['db'] = $this->db;
		$rawData['order_by'] = 'invoices.date desc';
		return getGridList($rawData);
		
	}
	function getBalLeft($fident){
		$this->db->select('balLeft');
		$this->db->where('idInvoice',$fident);
		return $this->db->get('invoices')->row();
	}
	function updateBalLeft($fident, $newAmount){
		$this->db->set('balLeft', $newAmount);
		$this->db->where('idInvoice', $fident);
		$this->db->update('invoices');
	}
	function saveInvoice( $rawData ){

		$id = (int)$rawData['idInvoice'];
		unset($rawData['idInvoice']);
		if ( (int)$rawData['onEdit'] == 0 ){
			$this->db->insert('invoices',unsetParams($rawData, 'invoices' ));
			return $this->db->insert_id();
		}else{
			$this->db->where('idInvoice',$id);
			$this->db->update( 'invoices', unsetParams( $rawData, 'invoices' ) );
		}
	}
	
	function saveCollectionDetails( $collectionDetails, $crInvoiceID ){
		// $this->db->insert_batch( 'receipts', $collectionDetails );
		$this->db->insert_batch( 'receipts', unsetParamsBatch( $collectionDetails, 'receipts') );
	}
	function savePaymentList( $paymentList, $crInvoiceID ){ 
		$this->db->insert_batch( 'postdated', unsetParamsBatch( $paymentList, 'postdated' ) ); 
	}
	function saveJournalDetails( $journalDetails,$crInvoiceID ){
		$this->db->delete( 'posting', array( 'idInvoice' => $crInvoiceID ) );
		$this->db->insert_batch( 'posting', unsetParamsBatch( $journalDetails, 'posting' ) );
	}
	function delReceiptsDetails($crInvoiceID){
		$this->db->delete( 'receipts', array( 'idInvoice' => $crInvoiceID ) );
	}
	function delPostdatedDetails($crInvoiceID){
		$this->db->delete( 'postdated', array( 'idInvoice' => $crInvoiceID ) );
	}
	
	function retrieveData( $idInvoice ){
		$this->db->select('*');
		$this->db->from('invoices');
		$this->db->where('idInvoice', $idInvoice);
		
		// to be uncommented when using the new database
		// $this->db->where_not_in('invoices.archived',1);
		
		return $this->db->get()->result_array();
	}
	function deleteCashReceipt($idInvoice){
		$this->db->delete( 'invoices' , array( 'idInvoice' => $idInvoice));
	}
	
	
}