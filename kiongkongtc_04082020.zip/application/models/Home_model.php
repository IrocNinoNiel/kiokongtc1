<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Home_model extends CI_Model {
	
	public function getCompany(){
		return $this->db->query("
			SELECT
				*
			FROM affiliate
			WHERE mainTag = 1
		")->row_array();
	}
	
	public function getAllAffiliate(){
		return $this->db->query("
			SELECT
				idAffiliate
				,affiliateName
			FROM affiliate
		")->result_array();
	}

	public function loginUser( $data ){
		
			// ,us.fullname as userFullName
			// ,comp.companyaffiliateName as companyName
			// ,aff.datestart as affiliateDateStart
			// ,comp.systemName
			// ,comp.companyaffiliateLogo as default_companyLogo
			
			// print_r($data);
			
			// die();
			
		// echo($data['config_idEu']);


		// die('test');
			
		$this->db->select("
			us.idEu as userID
			,emp.idEmployee as empID
			,us.username as userName
			,emp.status as employeeStatus
			,emp.name
			,(CASE us.userType
				WHEN 0 THEN 'System Administrator'
				WHEN 1 THEN 'Administrator'
				WHEN 2 THEN 'Supervisor'
				WHEN 3 THEN 'Staff'
			END) as userTypeName
			,us.userType as userTypeID
			,empaff.idAffiliate
			,aff.affiliateName
			,aff.tagLine as affiliateTagLine
			,aff.maintag
			,aff.reftag
			,aff.status as statusAffiliate
			,aff.logo as companyLogo
			,aff.accSchedule as affiliateAccSched
			,aff.month as affiliateMonth
			,aff.dateStart
			,(SELECT COUNT(*) FROM amodule as am WHERE am.idEu = us.idEu) as module_count
			,(SELECT COUNT(*) FROM employeeaffiliate as abb where abb.idEmployee=us.idEmployee and abb.idAffiliate =". $data['affiliateID']." ) as affiliate_count
		");
		$this->db->from("eu as us");
		$this->db->join("employee as emp","emp.idEmployee = us.idEmployee","left outer");
		$this->db->join("employeeaffiliate as empaff","empaff.idEmployee = us.idEmployee","left outer");
		$this->db->join("affiliate as aff","aff.idAffiliate = empaff.idAffiliate","left outer");
		// $this->db->join("companyaffiliate as comp","comp.companyaffiliateID = 1");
		
		// $this->db->where("emp.status",0);
		if( isset($data['config_idEu']) ){
			$this->db->where("us.idEu", $data['config_euID']);
		}
		else{
			$this->db->where("us.username",$data['username']);
			$this->db->where("us.password",md5($data['password']));
			$this->db->where("empaff.idAffiliate",$data['affiliateID']);
		}
		
		return $this->db->get()->row_object();
		// return $user;
		// $user = $this->db->get()->row_object();
	}
	
	public function getAffiliate(){
		$this->db->select("affiliateID,affiliateName");
		$this->db->where("status",1);
		$this->db->where("affiliateID != " . $this->AFFILIATEID);
		$this->db->from("affiliate");
		$this->db->order_by("affiliateName");
		return $this->db->get()->result_array();
	}
	
	public function getAdjustments(){
		$this->db->select("inv.invoiceID,CONCAT(ref.code,' - ',inv.referenceNo) as reference");
		$this->db->from("invoices as inv");
		$this->db->join("reference as ref","ref.refID = inv.referenceID");
		$this->db->where("inv.adjustmentconfirmed", 0);
		$this->db->where("inv.moduleID", 30);
		$this->db->where("inv.affiliateID = " . $this->AFFILIATEID);
		$this->db->order_by("inv.invoiceID desc");
		return $this->db->get()->result_array();
	}
	
	public function saveInitialRecords( $data ){
		
		/** company details **/
		$record = array(
			'companyName' => $data['affiliateName']
			,'companyAddress' => $data['address']
			,'TIN' => $data['tin']
			,'datestart' => $data['datestart']
			,'accountingsched' => $data['accountingsched']
			,'month' => $data['month']
			,'versionID' => $this->standards->getLastestSystemDetailsRecord()->versionID
		);
		$this->db->insert( 'companydetails' ,unsetParams( $record, 'companydetails' ) );
		
		/** company affiliate **/
		$record = array(
			'companyaffiliateName' => $data['affiliateName']
			,'companyaffiliateTagLine' => ''
		);
		$this->db->update( 
			'companyaffiliate'
			,unsetParams( $record, 'companyaffiliate' )
			,array( 'companyaffiliateID' => 1 )
		);
		
		/** affiliate **/
		$data['status'] = 1;
		$data['affLogo'] = $this->DEFAULT_COMPLOGO;
		$this->db->insert( 'affiliate' ,unsetParams( $data, 'affiliate' ) );
		$affiliateID =  $this->db->insert_id();
		
		/** update system admin user affilaiteID **/
		$record = array(
			'affiliateID' => $affiliateID
		);
		$this->db->update( 
			'eu'
			,unsetParams( $record, 'eu' )
			,array( 'euID' => $this->USERID )
		);
	}

	// check user credentials
	function checkUserLogin( $params ){
		$this->db->select( '*' );
		$this->db->from('eu');
		$this->db->where(  'euName', $params[ 'adminUsernameinitialCompanySetup_mainView' ]);
		$this->db->where( 'eupword', md5( $params[ 'adminPassinitialCompanySetup_mainView' ] ) );
		
		return $this->db->get()->result_array();
		// LQ();
		
	}
	
	function getAffiliateDetI( $affID ){
		$this->db->where( 'affiliateID', $affID );
		return $this->db->get( 'affiliate' )->row();
	}

	function getAffiliateByusername($username){
		$this->db->select('affiliate.idAffiliate AS id, affiliate.affiliateName as name');
		$this->db->from('eu');
		$this->db->join('employeeaffiliate', 'employeeaffiliate.idEmployee = eu.idEmployee', 'LEFT');
		$this->db->join('affiliate', 'employeeaffiliate.idAffiliate = affiliate.idAffiliate', 'LEFT');
		$this->db->where('eu.username',$username );
		$this->db->where_not_in('eu.archived',1);
		return $this->db->get()->result_array();
	}
}