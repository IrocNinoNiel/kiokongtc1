<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Bandr_model extends CI_Model {
	
	
    public function __construct()
    {
        parent::__construct();
		// $this->bois_db = aci_bois;
		// $this->deaddrop_db = $this->session->userdata('branch_company_name');
	}
	
	function GetBackUp(){
		$this->db->select('*');
		return $this->db->get('autobackup')->result_array();
	}
	
	function SaveSetting($data){
		// unset($data['module']);
		$this->db->trans_start();
		$cnt = $this->db->count_all_results("autobackup");
		if($cnt > 0){
			$this->db->where('idAB',1);
			$this->db->update('autobackup', unsetParams( $data, 'autobackup' ) );
		}
		else{
			unset($data['idAB']);
			$this->db->insert('autobackup',unsetParams( $data, 'autobackup' ) );
		}
		$this->db->trans_complete();
	}
	
	function Delete($id){
		$data = array('backupHistoryID'=>$id);
		$this->db->delete($this->deaddrop_db.'.backuphistory',$data);
	}
	
	function checkPassword(){
		$this->db->select('euID');
		$this->db->where('eupword',md5($this->input->post('pass')));
		$this->db->where('euID',(int)$this->session->userdata('USERID'));
		return $this->db->get('eu')->result_array();
		// $this->db->get('eu')->result_array();
		// LQ();
	}
	
	
}
?>