<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Inventorybalances_model extends CI_Model
{
   public function getItemClassifications(){
      return $this->db->select("
         idItemClass as id
         ,className as name
      ")
      ->where( 'archived' , 0 )
      ->get('itemclassification')->result_array();
   }

   public function getItems( $params ){
      $this->db->select("
         item.idItem as id
         ,itemName   as name
      ");

      if ( isset( $params['idAffiliate'] ) && $params['idAffiliate'] != 0 ) {
         $this->db->join( 'itemaffiliate' , 'itemaffiliate.idItem = item.idItem');
         $this->db->where( 'itemaffiliate.idAffiliate' , $params['idAffiliate'] ); 
      };

      if ( isset( $params['idItemClass'] ) && $params['idItemClass'] != 0 ) {
         $this->db->where( 'item.idItemClass' , $params['idItemClass'] ); 
      };

      $this->db->where( 'archived' , 0 );
      return $this->db->get( 'item' )->result_array();
   }

   public function getInventoryBalances( $params )
   {
      $this->db->SELECT("
            affiliateName
         , itemName
         , className
         , unitCode
         , latestReceivingCost.cost
         , reorderLevel
         , ( SUM( IFNULL( receiving.qty , 0 ) ) - SUM( IFNULL( releasing.qty , 0 ) ) ) as balance
      ")->FROM( "item" );

      $this->db->JOIN( "(
         SELECT max( idReceiving ) as idReceiving, idItem 
         FROM receiving GROUP BY idItem 
      ) AS maxReceivingID" , "maxReceivingID.idItem = item.idItem" , "LEFT" )
         ->JOIN( "(
            SELECT idReceiving, cost
            FROM receiving
         ) AS latestReceivingCost" , "latestReceivingCost.idReceiving = maxReceivingID.idReceiving" , "LEFT" );
      
      $this->db->JOIN( "receiving" , "receiving.idItem = item.idItem" , "LEFT" )
         ->JOIN( 
            "invoices recInvoice" 
            , "recInvoice.idInvoice = receiving.idInvoice AND recInvoice.archived not in( 1 ) AND recInvoice.idModule in ( 21 , 22 , 23 , 25 )" 
            , "LEFT" 
         )->JOIN( "affiliate recAff" , "recAff.idAffiliate = recInvoice.idAffiliate" );

      $this->db->JOIN( "
         (  SELECT
               releasing.fIdent 
               , releasing.idItem 
               , sum( ifnull(releasing.qty , 0) ) as qty
            FROM releasing

            LEFT JOIN invoices relInvoice 
            ON relInvoice.idInvoice = releasing.idInvoice  
            AND relInvoice.archived NOT IN( 1 )	
            AND relInvoice.idModule IN( 18 , 22 , 23 , 29 )
            
            group by releasing.fIdent , releasing.idItem , releasing.cost
         ) AS releasing" 
         , "releasing.fIdent = receiving.idReceiving AND releasing.idItem = receiving.idItem" 
         , "LEFT" 
      );

      $this->db->JOIN( "itemclassification" , "itemclassification.idItemClass = item.idItemClass" , "LEFT" );
      $this->db->JOIN( "unit" , "unit.idUnit = item.idUnit" , "LEFT" );
     
      if ( $params['idAffiliate'] != 0 ) $this->db->WHERE( 'recInvoice.idAffiliate' , $params['idAffiliate'] );
      if ( $params['idItem'] != 0 ) $this->db->WHERE( 'item.idItem' , $params['idItem'] ); 
      if ( $params['idItemClass'] != 0 ) $this->db->WHERE( 'item.idItemClass' , $params['idItemClass'] ); 
      
      $this->db->WHERE( 'recInvoice.date <= "'.$params['datefrom'].'" ');
      $this->db->WHERE_NOT_IN( "recInvoice.cancelTag" , 1 );
      $this->db->WHERE_NOT_IN( "item.archived" , 1 );
      $this->db->GROUP_BY( "item.idItem , recInvoice.idAffiliate , latestReceivingCost.cost" );
      return $this->db->get()->result_array();   
   }
}
