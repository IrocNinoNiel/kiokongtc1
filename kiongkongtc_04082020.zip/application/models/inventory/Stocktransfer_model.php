<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Developer: Mark Reynor D. Magriña
 * Module: Sales Module
 * Date: Feb 04, 2020
 * Finished: 
 * Description: 
 * DB Tables: 
 * */
class Stocktransfer_model extends CI_Model {
	
	function getGridListForPayments($rawData){
		
		/* Edited or saved cash receipts statments here */
		if( (int)$rawData['idInvoice'] != 0 || !$rawData['idInvoice'] ){
			// echo 'sulod ko edited record';
			
			$this->db->select("
				CONCAT(salesReference.code, ' - ',salesInvoices.referenceNum) as reference	
				,salesInvoices.idInvoice as salesIDInvoice
				,DATE_FORMAT(salesInvoices.date,'%Y-%m-%d') as date
				,(IF(salesInvoices.balLeft > 0,salesInvoices.balLeft,0) + receipts.amount) as receivables 
				,receipts.amount as collections
				,(( IF(salesInvoices.balLeft > 0,salesInvoices.balLeft,0) + receipts.amount) - receipts.amount ) as balance
			");
			$this->db->where('invoices.idInvoice', $rawData['idInvoice'] );
			
			$this->db->join('receipts','receipts.idInvoice = invoices.idInvoice','left outer');		
			$this->db->join('invoices as salesInvoices','salesInvoices.idInvoice = receipts.fident','left outer');
			$this->db->join('reference as salesReference','salesReference.idReference = salesInvoices.idReference','left outer');
		}
		else{ /* New sales record fetch statements here */
			// echo 'sulod ko new record';
			
			$this->db->select("
				CONCAT(reference.code, ' - ',invoices.referenceNum) as reference
				,invoices.idInvoice as salesIDInvoice
				,DATE_FORMAT(invoices.date,'%Y-%m-%d') as date
				,invoices.balLeft as receivables 
				,0 as collections
				,invoices.balLeft as balance
			");
			$this->db->where('invoices.pCode', $rawData['idCustomer'] );
			$this->db->where('invoices.date <=', $rawData['tDate']);
			$this->db->where('invoices.status',2);
		}
		$this->db->from('invoices');
		$this->db->where('invoices.pType',1);
		$this->db->join('reference','reference.idReference = invoices.idReference','left outer');
		return $this->db->get()->result_array();
	}
	
	/* function getCollectionDetails($rawData){
		$this->db->select("
			idPostdated,idInvoice,paymentMethod,(IF(chequeNo > 0,chequeNo,'')) as chequeNo,(IFNULL(NULL, date)) as date,amount,bank.bankName,idBankAccount
			,(CASE
				WHEN paymentMethod = 1 THEN 'Cash'
				ELSE 'Cheque'	
			END) as type
		");
		$this->db->from('postdated');
		$this->db->where('idInvoice',$rawData['idInvoice']);
		$this->db->join('bank','bank.idBank = postdated.idBankAccount','left outer');
		return $this->db->get()->result_array();		
	} */
	
	function getItems( $rawData ){
        if( isset( $rawData['idAffiliate']) ) {
            $qty = ( isset($rawData['qty']) ? $rawData['qty'] : 1 );
            $this->db->select(' item.idItem,item.itemName,item.barcode
								,unit.unitName
								,itemclassification.className
								,receivingSumQty.qtyLeft as availQty, ' . 
                                $qty . ' as qty
			');
            $this->db->where('itemaffiliate.idAffiliate', $rawData['idAffiliate']);
            if( isset($rawData['query']) && isset($rawData['itemNameIndicator']) ) $this->db->like('item.itemName', $rawData['query'],'both');
            elseif( isset($rawData['query']) ) $this->db->like('item.barcode', $rawData['query'],'both');
			$this->db->join('itemaffiliate','itemaffiliate.idItem = item.idItem','left outer');
            $this->db->join('itemclassification', 'itemclassification.idItemClass = item.idItemClass', 'LEFT');
            $this->db->join('unit', 'unit.idUnit = item.idUnit', 'LEFT');
			$this->db->join("
				(
					select SUM( IFNULL( receiving.qtyLeft, 0) ) as qtyLeft, receiving.idItem, invoices.date, invoices.idAffiliate from receiving 
					JOIN invoices on( invoices.idInvoice = receiving.idInvoice ) where invoices.idAffiliate = " . (int)$rawData['idAffiliate'] . "
					and DATE_FORMAT(invoices.date,'%Y-%m-%d') <= '". $rawData['date'] ."' and invoices.status = 2 AND invoices.archived NOT IN( 1 )
					GROUP BY receiving.idItem
				) as receivingSumQty
			",'receivingSumQty.idItem = item.idItem','left outer');
            return $this->db->get('item')->result_array();
        }
    }
	
	// select  SUM( IFNULL( receivingSumQty.qtyLeft, 0) ) as availQty from receiving
	// join invoices on( invoices.idInvoice = receiving.idInvoice )
	
	
	function getItemListDetails($rawData){
		$this->db->select("
					idstockTransfer,idInvoice,qtyTransferred,qtyReceived
					,item.itemName,item.barcode
					,unit.unitName
		");
		$this->db->from('stocktransfer');
		$this->db->where('idInvoice',$rawData['idInvoice']);
		$this->db->join('item','item.idItem = stocktransfer.idItem','left outer');
		$this->db->join('unit','unit.idUnit = item.idUnit','left outer');
		return $this->db->get()->result_array();
	}
	
	function getStockTransferDetails($rawData){
		$this->db->select("
				invoices.idInvoice,DATE_FORMAT(invoices.date, '%Y-%m-%d') as date
				,(CASE 
						WHEN invoices.status = 1 THEN 'Pending'
						WHEN invoices.status = 2 THEN 'Approved'
						ELSE 'Cancelled'
				END) as status
				,CONCAT( reference.code,'-',invoices.referenceNum ) as reference
				,affiliateSource.affiliateName as sourceAffiliate
				,affiliateReceiver.affiliateName as receiverAffiliate
				,empNoted.name as notedByName
				,empPrepare.name as preparedByName
		");
		$this->db->where('invoices.idModule', 43);
		$this->db->where_not_in('invoices.archived',1);
		$this->db->from('invoices');
		$this->db->order_by('idInvoice','desc');
		$this->db->join('reference','reference.idReference = invoices.idReference','left outer');
		$this->db->join('affiliate as affiliateSource','affiliateSource.idAffiliate = invoices.idAffiliate','');
		$this->db->join('affiliate as affiliateReceiver','affiliateReceiver.idAffiliate = invoices.pCode','');
		$this->db->join('eu as euNoted','euNoted.idEu = invoices.notedby','left outer');
		$this->db->join('employee as empNoted','empNoted.idEmployee = euNoted.idEmployee','left outer');
		$this->db->join('eu euPrepared','euPrepared.idEu = invoices.preparedBy','left outer');
		$this->db->join('employee as empPrepare','empPrepare.idEmployee = euPrepared.idEmployee','left outer');
		
		return $this->db->get()->result_array();
	}
	function retrieveData($rawData){
		$this->db->select(" idInvoice,idAffiliate,idReference,referenceNum,idModule,idCostCenter,date,pCode
							,employee.name as transferredBy
		");
		$this->db->from('invoices');
		$this->db->where('idInvoice',(int)$rawData['idInvoice']);
		$this->db->join('eu','eu.idEu = invoices.preparedBy','left outer');
		$this->db->join('employee','employee.idEmployee = eu.idEmployee','left outer');
		return $this->db->get()->result_array();
	}
	function saveInvoiceStockTransfer($rawData){
		$id = (int)$rawData['idInvoice'];
		unset($rawData['idInvoice']);
		if( (int)$rawData['onEdit'] == 0 ){
			$this->db->insert( 'invoices', unsetParams($rawData, 'invoices') );
			return $this->db->insert_id();
		}else{
			$this->db->where('idInvoice',$id);
			$this->db->update('invoices', unsetParams($rawData, 'invoices') );
		}
	}	
	
	function saveGridItemList($gridItemList,$stInvoiceID){
		$this->db->delete( 'stocktransfer', array('idInvoice'=>$stInvoiceID) );
		$this->db->insert_batch( 'stockTransfer', unsetParamsBatch( $gridItemList, 'stockTransfer' ) );
	}
	function saveJournalDetails($journalDetails,$stInvoiceID){
		$this->db->delete( 'posting', array( 'idInvoice' => $stInvoiceID ) );
		$this->db->insert_batch( 'posting', unsetParamsBatch( $journalDetails, 'posting' ) );
	}
	
	function deleteStockTransferRecord($idInvoice){
		$this->db->delete('invoices', array( 'idInvoice'=> $idInvoice ) );
	}
	function deleteStockTransferDetails($idInvoice){
		$this->db->delete('stocktransfer', array( 'idInvoice'=> $idInvoice ) );
	}
	
	
}